//! Unicode-safe text searching and replacing. Match offsets are UTF-8 byte ranges.
use regex::{Regex, RegexBuilder};

#[derive(Clone, Debug, Default)]
pub struct Matches {
    pub locations: Vec<(usize, usize)>,
    pub truncated: bool,
}

pub fn matcher(query: &str, regex_mode: bool, case_sensitive: bool) -> Result<Regex, String> {
    if query.is_empty() { return Err("Search term is empty".into()); }
    let pattern = if regex_mode { query.to_string() } else { regex::escape(query) };
    RegexBuilder::new(&pattern)
        .case_insensitive(!case_sensitive)
        .multi_line(true)
        .build().map_err(|e| format!("Invalid search expression: {e}"))
}

pub fn find(text: &str, query: &str, regex_mode: bool, case_sensitive: bool, limit: usize)
    -> Result<Matches, String> {
    if query.is_empty() { return Ok(Matches::default()); }
    let regex = matcher(query, regex_mode, case_sensitive)?;
    let mut locations = Vec::new();
    let mut truncated = false;
    for m in regex.find_iter(text) {
        if locations.len() >= limit { truncated = true; break; }
        locations.push((m.start(), m.end()));
    }
    Ok(Matches { locations, truncated })
}

pub fn replace_all(text: &str, query: &str, replacement: &str, regex_mode: bool,
                   case_sensitive: bool) -> Result<(String, usize), String> {
    let regex = matcher(query, regex_mode, case_sensitive)?;
    let count = regex.find_iter(text).count();
    if count == 0 { return Ok((text.to_owned(), 0)); }
    let updated = if regex_mode {
        regex.replace_all(text, replacement).into_owned()
    } else {
        regex.replace_all(text, regex::NoExpand(replacement)).into_owned()
    };
    Ok((updated, count))
}

pub fn byte_range_to_chars(text: &str, a: usize, b: usize) -> (usize, usize) {
    (text[..a].chars().count(), text[..b].chars().count())
}

pub fn byte_offset_for_line(text: &str, line_one_based: usize) -> usize {
    if line_one_based <= 1 { return 0; }
    text.match_indices('\n').nth(line_one_based - 2)
        .map(|(idx, _)| idx + 1).unwrap_or(text.len())
}

pub fn line_col_at_char(text: &str, char_pos: usize) -> (usize, usize) {
    let mut line = 1; let mut col = 1;
    for ch in text.chars().take(char_pos) {
        if ch == '\n' { line += 1; col = 1; } else { col += 1; }
    }
    (line, col)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn unicode_ranges_and_case() {
        let text = "あa\nあA";
        let matches = find(text, "あ", false, true, 99).unwrap();
        assert_eq!(matches.locations, vec![(0, 3), (5, 8)]);
        assert_eq!(byte_range_to_chars(text, 5, 8), (3, 4));
        assert_eq!(find(text, "a", false, false, 9).unwrap().locations.len(), 2);
    }
    #[test] fn regex_groups_and_literal_dollar() {
        assert_eq!(replace_all("a12 b34", r"([a-z])(\d+)", "$2-$1", true, true).unwrap().0, "12-a 34-b");
        assert_eq!(replace_all("one one", "one", "$5", false, true).unwrap().0, "$5 $5");
    }
    #[test] fn line_offsets() {
        assert_eq!(byte_offset_for_line("a\nあ\nx", 3), 6);
        assert_eq!(line_col_at_char("a\nあ\nx", 3), (2, 2));
    }
    #[test] fn invalid_regex() { assert!(matcher("[", true, true).is_err()); }
}
