//! Bounded recursive workspace-wide search, entirely offline and in Rust.
use crate::{document, search};
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Hit { pub path: PathBuf, pub line: usize, pub excerpt: String }
#[derive(Debug, Clone)]
pub struct SearchReport { pub hits: Vec<Hit>, pub visited: usize, pub skipped: usize, pub error: Option<String> }

const MAX_FILE_BYTES: u64 = 2 * 1024 * 1024;
const MAX_SCAN_FILES: usize = 8000;
const MAX_HITS: usize = 1000;

/// Do not follow symlinked folders, and limit breadth, recursion and file size.
pub fn search_workspace(root: &Path, pattern: &str, regex_mode: bool, case_sensitive: bool) -> SearchReport {
    let mut report = SearchReport { hits: Vec::new(), visited: 0, skipped: 0, error: None };
    let matcher = match search::matcher(pattern, regex_mode, case_sensitive) {
        Ok(matcher) => matcher,
        Err(err) => { report.error = Some(err); return report; }
    };
    let mut stack = vec![(root.to_path_buf(), 0usize)];
    while let Some((dir, depth)) = stack.pop() {
        if depth >= 12 || report.visited >= MAX_SCAN_FILES || report.hits.len() >= MAX_HITS { continue; }
        let Ok(entries) = fs::read_dir(&dir) else { report.skipped += 1; continue; };
        for entry in entries.flatten() {
            let path = entry.path();
            let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
            if matches!(name, ".git" | "target" | "node_modules" | ".venv" | "__pycache__" | ".idea" | ".vs") { continue; }
            let Ok(ft) = entry.file_type() else { report.skipped += 1; continue; };
            if ft.is_symlink() { continue; }
            if ft.is_dir() { stack.push((path, depth+1)); continue; }
            if !ft.is_file() { continue; }
            if report.visited >= MAX_SCAN_FILES || report.hits.len() >= MAX_HITS { break; }
            report.visited += 1;
            let Ok(md) = entry.metadata() else { report.skipped += 1; continue; };
            if md.len() > MAX_FILE_BYTES { report.skipped += 1; continue; }
            let Ok(raw) = fs::read(&path) else { report.skipped += 1; continue; };
            let Ok(decoded) = document::decode_bytes(&raw) else { report.skipped += 1; continue; };
            for (index, line) in decoded.text.lines().enumerate() {
                if matcher.is_match(line) {
                    let excerpt = line.trim();
                    let excerpt = if excerpt.chars().count() > 180 {
                        format!("{}…", excerpt.chars().take(180).collect::<String>())
                    } else { excerpt.to_owned() };
                    report.hits.push(Hit { path: path.clone(), line: index+1, excerpt });
                    if report.hits.len() >= MAX_HITS { break; }
                }
            }
        }
    }
    report
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn finds_matching_lines() {
        let base = std::env::temp_dir().join(format!("toneedit-search-{}", std::process::id()));
        let _ = fs::remove_dir_all(&base);
        fs::create_dir_all(base.join("src")).unwrap();
        fs::write(base.join("src").join("main.rs"), "fn main() {\n // TODO: test\n}\n").unwrap();
        fs::write(base.join("readme.txt"), "nothing here\n").unwrap();
        let report = search_workspace(&base, "TODO", false, true);
        assert_eq!(report.hits.len(), 1);
        assert_eq!(report.hits[0].line, 2);
        fs::remove_dir_all(&base).unwrap();
    }
}
