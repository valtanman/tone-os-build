#![cfg_attr(all(target_os = "windows", not(debug_assertions)), windows_subsystem = "windows")]
//! ToneEdit Studio — a native desktop editor, written entirely in Rust.
//! All disk writes are user-triggered or recovery-session autosaves.
mod document;
mod search;
mod syntax;
mod workspace;
mod ai;
mod google_oauth;
mod components;

use document::{Encoding, LineEnding};
use eframe::egui::{self, Key};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs::{self, File};
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::mpsc::{self, Receiver, Sender};
use std::thread;
use std::time::{Duration, Instant, SystemTime};

fn main() -> eframe::Result<()> {
    // This runs without opening a desktop window. Windows release automation
    // uses it to exercise the real compiled executable and core disk I/O.
    if std::env::args().any(|arg| arg == "--self-test") {
        match smoke_test() {
            Ok(()) => return Ok(()),
            Err(error) => { eprintln!("ToneEdit self-test failed: {error}"); std::process::exit(1); }
        }
    }
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("ToneEdit Studio 1.2.1")
            .with_inner_size([1400.0, 870.0])
            .with_min_inner_size([800.0, 520.0]),
        ..Default::default()
    };
    eframe::run_native("ToneEdit Studio", options, Box::new(|cc| {
        setup_fonts(&cc.egui_ctx);
        Ok(Box::new(EditorApp::new(&cc.egui_ctx)))
    }))
}

fn smoke_test() -> Result<(), String> {
    let scratch = std::env::temp_dir().join(format!("toneedit-self-test-{}", std::process::id()));
    fs::create_dir_all(&scratch).map_err(|e| e.to_string())?;
    let file = scratch.join("multilingual.txt");
    let result = (|| {
        document::save(&file, "日本語\nRust 🌸", Encoding::Utf8Bom, LineEnding::CrLf)?;
        let loaded = document::load(&file)?;
        if loaded.text != "日本語\nRust 🌸" || loaded.encoding != Encoding::Utf8Bom
            || loaded.newline != LineEnding::CrLf {
            return Err("UTF-8 BOM / CRLF round trip failed".to_owned());
        }
        let hits = search::find(&loaded.text, "Rust", false, true, 16)?;
        if hits.locations.len() != 1 { return Err("Search self-test failed".to_owned()); }
        document::save(&file, "更新", Encoding::Utf16Le, LineEnding::Lf)?;
        let backup = fs::read(document::backup_path(&file)).map_err(|e| e.to_string())?;
        if document::decode_bytes(&backup)?.text != "日本語\nRust 🌸" {
            return Err("Backup self-test failed".into());
        }
        Ok(())
    })();
    let _ = fs::remove_dir_all(scratch);
    result
}

fn setup_fonts(ctx: &egui::Context) {
    // egui's built-in fonts remain in place. If available, add a CJK fallback.
    let candidates: &[&str] = if cfg!(windows) {
        &["C:/Windows/Fonts/meiryo.ttc", "C:/Windows/Fonts/YuGothR.ttc", "C:/Windows/Fonts/msgothic.ttc"]
    } else if cfg!(target_os = "macos") {
        &["/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc", "/System/Library/Fonts/Hiragino Sans GB.ttc"]
    } else {
        &["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    };
    if let Some(bytes) = candidates.iter().find_map(|p| fs::read(p).ok()) {
        let mut fonts = egui::FontDefinitions::default();
        fonts.font_data.insert("system_cjk".into(), egui::FontData::from_owned(bytes).into());
        for family in [egui::FontFamily::Proportional, egui::FontFamily::Monospace] {
            fonts.families.entry(family).or_default().push("system_cjk".into());
        }
        ctx.set_fonts(fonts);
    }
}

#[derive(Clone)]
struct Document {
    id: u64,
    path: Option<PathBuf>,
    text: String,
    dirty: bool,
    encoding: Encoding,
    newline: LineEnding,
    disk_modified: Option<SystemTime>,
    disk_fingerprint: Option<[u8; 32]>,
    mixed_endings: bool,
}

/// The contents hash supplements modification times: network drives and file
/// systems with coarse timestamps can report the same time after a rewrite.
fn fingerprint(path: &Path) -> Result<[u8; 32], String> {
    let mut file = File::open(path).map_err(|e| format!("Cannot inspect file contents: {e}"))?;
    let mut digest = Sha256::new();
    let mut block = [0u8; 8192];
    loop {
        let n = file.read(&mut block).map_err(|e| format!("Cannot inspect file contents: {e}"))?;
        if n == 0 { break; }
        digest.update(&block[..n]);
    }
    Ok(digest.finalize().into())
}
impl Document {
    fn empty(id: u64) -> Self {
        Self { id, path: None, text: String::new(), dirty: false,
            encoding: Encoding::Utf8, newline: LineEnding::Lf,
            disk_modified: None, disk_fingerprint: None, mixed_endings: false }
    }
    fn title(&self) -> String {
        self.path.as_ref().and_then(|p| p.file_name()).map(|s| s.to_string_lossy().into_owned())
            .unwrap_or_else(|| format!("Untitled-{}", self.id))
    }
    fn display_title(&self) -> String { format!("{}{}", self.title(), if self.dirty { " ●" } else { "" }) }
    fn from_file(id: u64, path: PathBuf) -> Result<Self, String> {
        let result = document::load(&path)?;
        let disk_fingerprint = Some(fingerprint(&path)?);
        Ok(Self { id, disk_modified: document::file_modification(&path), disk_fingerprint,
            path: Some(path),
            text: result.text, dirty: false, encoding: result.encoding, newline: result.newline,
            mixed_endings: result.mixed_newlines })
    }
    fn save(&mut self, path: &Path, force_overwrite: bool) -> Result<(), String> {
        if !force_overwrite && self.path.as_deref() == Some(path) {
            // A file deleted between opening and saving is also an external change.
            // Do not silently resurrect it. The explicit force command can override.
            if !path.is_file() {
                return Err("The original file was removed or replaced. Use Save As to avoid data loss.".into());
            }
            if self.disk_modified != document::file_modification(path) {
                return Err("The file was changed or removed by another program. Use Save As to preserve both versions or explicitly overwrite the changed file.".into());
            }
            if let Some(known) = self.disk_fingerprint {
                if fingerprint(path)? != known {
                    return Err("The contents of this file changed outside ToneEdit Studio, even though its timestamp did not. Save As or explicitly overwrite it.".into());
                }
            }
        }
        document::save(path, &self.text, self.encoding, self.newline)?;
        self.path = Some(path.to_owned());
        self.disk_modified = document::file_modification(path);
        self.disk_fingerprint = Some(fingerprint(path)?);
        self.dirty = false;
        self.mixed_endings = false;
        Ok(())
    }
}

#[derive(Debug, Serialize, Deserialize)]
struct SavedDoc {
    path: Option<PathBuf>,
    dirty: bool,
    /// Snapshots only for new/dirty tabs, so clean files load from disk at next start.
    content: Option<String>,
    encoding: Encoding,
    newline: LineEnding,
    #[serde(default)]
    disk_modified_nanos: Option<u64>,
    #[serde(default)]
    disk_fingerprint: Option<[u8; 32]>,
}
#[derive(Debug, Serialize, Deserialize)]
struct Session {
    docs: Vec<SavedDoc>,
    active: usize,
    workspace: Option<PathBuf>,
    recent: Vec<PathBuf>,
    dark: bool,
    font_size: f32,
    #[serde(default = "default_show_explorer")]
    show_explorer: bool,
    #[serde(default)]
    show_search: bool,
    #[serde(default)]
    show_preview: bool,
    #[serde(default)]
    show_console: bool,
    #[serde(default)]
    show_ai: bool,
}

fn default_show_explorer() -> bool { true }

#[derive(Default)]
struct FindPanel {
    open: bool,
    term: String,
    replace: String,
    regex: bool,
    case_sensitive: bool,
    results: search::Matches,
    selected: usize,
    error: String,
}

#[derive(Debug, Clone, Copy)]
enum CargoAction { Check, Test, Build, Format }
impl CargoAction {
    fn args(self) -> &'static [&'static str] {
        match self {
            Self::Check => &["check"], Self::Test => &["test"],
            Self::Build => &["build", "--release"], Self::Format => &["fmt", "--all"],
        }
    }
    fn label(self) -> &'static str {
        match self { Self::Check => "Cargo check", Self::Test => "Cargo test",
                     Self::Build => "Cargo build --release", Self::Format => "Cargo fmt" }
    }
}

#[derive(Debug)]
enum Action {
    New, OpenDialog, OpenFile(PathBuf), OpenFolder,
    Save, SaveAs, SaveAll, SaveForce, Close(u64), Select(usize),
    RefreshSearch, FindNext(bool), ReplaceOne, ReplaceAll,
    Goto(usize), ToggleFind, ToggleGoto, TogglePreview,
    JsonPretty, JsonCompact, TrimTrailingWhitespace, SortLines,
    Cargo(CargoAction), ToggleTheme, FontSize(f32),
    ToggleExplorer, ComponentsSettings,
    ReloadFile, ShowHelp, SearchWorkspace, OpenAt(PathBuf, usize),
    ToggleAi, AiSettings,
}

enum CloseChoice { Save, Discard, Cancel }
struct TaskResult { title: String, output: String }

struct EditorApp {
    ai: ai::AiWorkspace,
    docs: Vec<Document>,
    next_id: u64,
    active: usize,
    workspace: Option<PathBuf>,
    recent: Vec<PathBuf>,
    find: FindPanel,
    goto_open: bool,
    goto_input: String,
    show_preview: bool,
    show_explorer: bool,
    components_open: bool,
    show_console: bool,
    show_help: bool,
    dark: bool,
    font_size: f32,
    pending_close: Option<u64>,
    jump: Option<(usize, usize)>,
    cursor_char: usize,
    warning: Option<String>,
    notice: Option<String>,
    status: String,
    console: String,
    task_running: bool,
    task_tx: Sender<TaskResult>,
    task_rx: Receiver<TaskResult>,
    search_tx: Sender<workspace::SearchReport>,
    search_rx: Receiver<workspace::SearchReport>,
    workspace_hits: Vec<workspace::Hit>,
    workspace_search_running: bool,
    workspace_search_summary: String,
    state_path: PathBuf,
    last_recovery: Instant,
}

fn default_state_path() -> PathBuf {
    if let Some(root) = std::env::var_os("APPDATA") {
        return PathBuf::from(root).join("ToneEditStudio").join("session.json");
    }
    if let Some(root) = std::env::var_os("XDG_STATE_HOME") {
        return PathBuf::from(root).join("toneedit-studio").join("session.json");
    }
    std::env::var_os("HOME").map(PathBuf::from).unwrap_or_else(std::env::temp_dir)
        .join(".toneedit-studio").join("session.json")
}

impl EditorApp {
    fn new(ctx: &egui::Context) -> Self {
        let state_path = default_state_path();
        let (task_tx, task_rx) = mpsc::channel();
        let (search_tx, search_rx) = mpsc::channel();
        let mut app = Self {
            ai: ai::AiWorkspace::new(),
            docs: vec![], next_id: 1, active: 0,
            workspace: None, recent: vec![], find: FindPanel::default(),
            goto_open: false, goto_input: "1".into(), show_preview: false,
            show_explorer: true, components_open: false,
            show_console: false, show_help: false, dark: true, font_size: 14.0,
            pending_close: None, jump: None, cursor_char: 0,
            warning: None, notice: None, status: "Ready".into(), console: String::new(),
            task_running: false, task_tx, task_rx, search_tx, search_rx,
            workspace_hits: vec![], workspace_search_running: false, workspace_search_summary: String::new(),
            state_path, last_recovery: Instant::now(),
        };
        app.restore();
        if app.docs.is_empty() { app.add_empty(); }
        components::theme::apply(ctx, app.dark);
        app
    }

    fn add_empty(&mut self) {
        let id = self.alloc_id();
        self.docs.push(Document::empty(id));
        self.active = self.docs.len() - 1;
        self.clear_search();
    }
    fn alloc_id(&mut self) -> u64 { let n = self.next_id; self.next_id += 1; n }
    fn active_doc(&self) -> Option<&Document> { self.docs.get(self.active) }
    fn active_doc_mut(&mut self) -> Option<&mut Document> { self.docs.get_mut(self.active) }
    fn show_error(&mut self, detail: impl Into<String>) { self.warning = Some(detail.into()); }
    fn show_notice(&mut self, detail: impl Into<String>) { self.notice = Some(detail.into()); }
    fn clear_search(&mut self) {
        self.find.results = search::Matches::default();
        self.find.selected = 0;
        self.find.error.clear();
        self.jump = None;
    }

    fn modified_nanos(time: Option<SystemTime>) -> Option<u64> {
        time.and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
            .and_then(|d| u64::try_from(d.as_nanos()).ok())
    }

    fn restore(&mut self) {
        let Ok(text) = fs::read_to_string(&self.state_path) else { return; };
        let Ok(saved) = serde_json::from_str::<Session>(&text) else { return; };
        self.workspace = saved.workspace.filter(|p| p.is_dir());
        self.recent = saved.recent.into_iter().filter(|p| p.is_file()).take(12).collect();
        self.dark = saved.dark;
        self.font_size = saved.font_size.clamp(10.0, 28.0);
        self.show_explorer = saved.show_explorer;
        self.find.open = saved.show_search;
        self.show_preview = saved.show_preview;
        self.show_console = saved.show_console;
        self.ai.visible = saved.show_ai;
        for sd in saved.docs {
            let id = self.alloc_id();
            let doc = if let Some(content) = sd.content {
                Document { id, path: sd.path.clone(), text: content, dirty: sd.dirty,
                    encoding: sd.encoding, newline: sd.newline,
                    disk_modified: sd.disk_modified_nanos.map(|ns| std::time::UNIX_EPOCH + Duration::from_nanos(ns)),
                    disk_fingerprint: sd.disk_fingerprint, mixed_endings: false }
            } else if let Some(path) = sd.path {
                match Document::from_file(id, path) { Ok(doc) => doc, Err(_) => continue }
            } else { Document::empty(id) };
            self.docs.push(doc);
        }
        if !self.docs.is_empty() { self.active = saved.active.min(self.docs.len() - 1); }
    }

    fn persist(&self) {
        let session = Session {
            docs: self.docs.iter().map(|d| SavedDoc {
                path: d.path.clone(), dirty: d.dirty,
                content: if d.dirty || d.path.is_none() { Some(d.text.clone()) } else { None },
                encoding: d.encoding, newline: d.newline,
                disk_modified_nanos: Self::modified_nanos(d.disk_modified),
                disk_fingerprint: d.disk_fingerprint,
            }).collect(),
            active: self.active, workspace: self.workspace.clone(), recent: self.recent.clone(),
            dark: self.dark, font_size: self.font_size,
            show_explorer: self.show_explorer,
            show_search: self.find.open,
            show_preview: self.show_preview,
            show_console: self.show_console,
            show_ai: self.ai.visible,
        };
        if let Ok(json) = serde_json::to_string(&session) {
            if let Err(e) = document::save_state(&self.state_path, &json) {
                eprintln!("Recovery session save failed: {e}");
            }
        }
    }

    fn track_recent(&mut self, path: &Path) {
        self.recent.retain(|p| p != path);
        self.recent.insert(0, path.to_owned());
        self.recent.truncate(12);
    }

    fn open_file(&mut self, path: PathBuf) {
        if path.is_dir() { self.workspace = Some(path); self.persist(); return; }
        let canonical = fs::canonicalize(&path).unwrap_or(path);
        if let Some(i) = self.docs.iter().position(|d| d.path.as_ref() == Some(&canonical)) {
            self.active = i;
            self.clear_search();
            return;
        }
        let id = self.alloc_id();
        match Document::from_file(id, canonical.clone()) {
            Ok(doc) => {
                if doc.mixed_endings {
                    self.show_notice("This file contains mixed newline styles. Saving will normalize them to the predominant style.");
                }
                self.docs.push(doc);
                self.active = self.docs.len() - 1;
                self.track_recent(&canonical);
                self.clear_search();
                self.persist();
            }
            Err(err) => self.show_error(format!("{}: {err}", canonical.display())),
        }
    }

    fn save_active(&mut self, as_new: bool, force: bool) -> bool {
        if self.docs.is_empty() { return false; }
        let original_path = self.docs[self.active].path.clone();
        let path = if !as_new { original_path } else { None };
        let path = match path {
            Some(path) => path,
            None => {
                let dialog = rfd::FileDialog::new().set_title("Save document");
                let dialog = if let Some(dir) = self.docs[self.active].path.as_ref().and_then(|p| p.parent()) {
                    dialog.set_directory(dir)
                } else if let Some(dir) = &self.workspace { dialog.set_directory(dir) } else { dialog };
                let dialog = dialog.set_file_name(&self.docs[self.active].title());
                match dialog.save_file() { Some(path) => path, None => return false }
            }
        };
        // A native Save As dialog can return a different spelling (relative path,
        // symbolic link, 8.3 filename or changed letter case) of an already open
        // file. Normalize existing destinations before checking for collisions.
        let normalized = fs::canonicalize(&path).unwrap_or_else(|_| path.clone());
        if self.docs.iter().enumerate().any(|(index, doc)| {
            index != self.active && doc.path.as_ref().is_some_and(|other| {
                fs::canonicalize(other).unwrap_or_else(|_| other.clone()) == normalized
            })
        }) {
            self.show_error("This file is already open in another tab. Choose a different Save As destination.");
            return false;
        }
        // Save As must not silently bypass the external-change check when the
        // chosen destination is actually the current document.
        let result = self.docs[self.active].save(&normalized, force && !as_new);
        match result {
            Ok(()) => {
                self.track_recent(&normalized);
                self.status = format!("Saved {}", normalized.display());
                self.persist();
                true
            }
            Err(e) => { self.show_error(e); false }
        }
    }

    fn save_all(&mut self) {
        let initial = self.active;
        for index in 0..self.docs.len() {
            if self.docs[index].dirty {
                self.active = index;
                if !self.save_active(false, false) { break; }
            }
        }
        self.active = initial.min(self.docs.len().saturating_sub(1));
    }

    fn close_doc(&mut self, id: u64) {
        let Some(index) = self.docs.iter().position(|d| d.id == id) else { return; };
        if self.docs[index].dirty { self.pending_close = Some(id); return; }
        self.remove_doc(id);
    }
    fn remove_doc(&mut self, id: u64) {
        if let Some(index) = self.docs.iter().position(|d| d.id == id) {
            self.docs.remove(index);
            if self.docs.is_empty() { self.add_empty(); }
            else if self.active >= self.docs.len() { self.active = self.docs.len() - 1; }
            else if index < self.active { self.active -= 1; }
            self.clear_search();
            self.persist();
        }
    }

    fn refresh_search(&mut self) {
        let Some(doc) = self.active_doc() else { return; };
        let result = search::find(&doc.text, &self.find.term, self.find.regex,
                                  self.find.case_sensitive, 20_000);
        match result {
            Ok(m) => {
                self.find.results = m;
                self.find.selected = self.find.selected.min(self.find.results.locations.len().saturating_sub(1));
                self.find.error.clear();
            }
            Err(e) => { self.find.results = search::Matches::default(); self.find.error = e; }
        }
    }

    fn jump_match(&mut self, forwards: bool) {
        let len = self.find.results.locations.len();
        if len == 0 { return; }
        self.find.selected = if forwards { (self.find.selected + 1) % len }
                             else { (self.find.selected + len - 1) % len };
        self.select_match();
    }
    fn select_match(&mut self) {
        let Some(&(a,b)) = self.find.results.locations.get(self.find.selected) else { return; };
        if let Some(doc) = self.active_doc() {
            self.jump = Some(search::byte_range_to_chars(&doc.text, a, b));
        }
    }

    fn replace_one(&mut self) {
        if self.find.term.is_empty() { return; }
        let index = self.find.selected;
        let replacement = self.find.replace.clone();
        let Some(&(a,b)) = self.find.results.locations.get(index) else { return; };
        if let Some(doc) = self.active_doc_mut() {
            if doc.text.is_char_boundary(a) && doc.text.is_char_boundary(b) {
                // Single replacement is literal; Replace All supports regex capture expansion.
                doc.text.replace_range(a..b, &replacement);
                doc.dirty = true;
            }
        }
        self.refresh_search();
        if !self.find.results.locations.is_empty() {
            self.find.selected = index.min(self.find.results.locations.len()-1);
            self.select_match();
        }
    }
    fn replace_all(&mut self) {
        let Some(doc) = self.active_doc() else { return; };
        let result = search::replace_all(&doc.text, &self.find.term, &self.find.replace,
                                         self.find.regex, self.find.case_sensitive);
        match result {
            Ok((text,count)) => {
                if count > 0 {
                    if let Some(doc) = self.active_doc_mut() { doc.text = text; doc.dirty = true; }
                    self.refresh_search();
                }
                self.status = format!("Replaced {count} occurrence(s)");
            }
            Err(e) => self.show_error(e),
        }
    }

    fn jump_to_line(&mut self, line: usize) {
        if let Some(doc) = self.active_doc() {
            let byte = search::byte_offset_for_line(&doc.text, line);
            let char_position = doc.text[..byte].chars().count();
            self.jump = Some((char_position, char_position));
            self.status = format!("Go to line {line}");
        }
    }

    fn transform_text(&mut self, action: &Action) {
        let Some(doc) = self.active_doc() else { return; };
        let original = doc.text.clone();
        let result: Result<String,String> = match action {
            Action::JsonPretty => serde_json::from_str::<serde_json::Value>(&original)
                .and_then(|v| serde_json::to_string_pretty(&v)).map_err(|e| e.to_string()),
            Action::JsonCompact => serde_json::from_str::<serde_json::Value>(&original)
                .and_then(|v| serde_json::to_string(&v)).map_err(|e| e.to_string()),
            Action::TrimTrailingWhitespace => Ok(original.split('\n')
                .map(|s| s.trim_end_matches(|c| c == ' ' || c == '\t')).collect::<Vec<_>>().join("\n")),
            Action::SortLines => {
                let mut lines = original.split('\n').collect::<Vec<_>>();
                lines.sort_unstable();
                Ok(lines.join("\n"))
            }
            _ => return,
        };
        match result {
            Ok(updated) => {
                if updated != original {
                    if let Some(doc) = self.active_doc_mut() { doc.text = updated; doc.dirty = true; }
                    self.refresh_search();
                    self.status = "Document transformed (Ctrl+Z to undo in editor may not apply to menu transforms; use backups)".into();
                }
            }
            Err(err) => self.show_error(format!("Format failed: {err}")),
        }
    }

    fn run_cargo(&mut self, action: CargoAction) {
        if self.task_running { self.show_notice("A Cargo command is already running"); return; }
        let base = self.workspace.clone().or_else(|| self.active_doc().and_then(|d| d.path.as_ref())
            .and_then(|p| p.parent()).map(Path::to_path_buf));
        let manifest_dir = base.and_then(|p| p.ancestors().take(12)
            .find(|ancestor| ancestor.join("Cargo.toml").is_file()).map(Path::to_path_buf));
        let Some(directory) = manifest_dir else {
            self.show_error("Open a Rust workspace with Cargo.toml before using Cargo tools");
            return;
        };
        let tx = self.task_tx.clone();
        self.task_running = true; self.show_console = true;
        self.console = format!("Running {} in {}\n\n", action.label(), directory.display());
        thread::spawn(move || {
            let result = Command::new("cargo").args(action.args()).current_dir(directory).output();
            let output = match result {
                Ok(out) => {
                    let mut combined = String::from_utf8_lossy(&out.stdout).into_owned();
                    combined.push_str(&String::from_utf8_lossy(&out.stderr));
                    if combined.len() > 250_000 {
                        let cut = combined.char_indices().map(|(i,_)| i)
                            .find(|i| *i >= combined.len()-250_000).unwrap_or(0);
                        combined = format!("[Truncated older output]\n{}", &combined[cut..]);
                    }
                    combined.push_str(&format!("\nExit status: {}", out.status));
                    combined
                }
                Err(e) => format!("Could not start cargo: {e}\nInstall Rust from https://rustup.rs/ and retry"),
            };
            let _ = tx.send(TaskResult { title: action.label().to_string(), output });
        });
    }

    fn run_workspace_search(&mut self) {
        if self.workspace_search_running { return; }
        let Some(root) = self.workspace.clone() else {
            self.show_error("Open a folder first to search its files"); return;
        };
        if self.find.term.is_empty() {
            self.show_error("Enter a search term in the Find bar first"); return;
        }
        let term = self.find.term.clone();
        let regex = self.find.regex;
        let case_sensitive = self.find.case_sensitive;
        let tx = self.search_tx.clone();
        self.workspace_search_running = true;
        self.workspace_hits.clear();
        self.workspace_search_summary = "Searching workspace...".into();
        self.show_console = true;
        thread::spawn(move || {
            let report = workspace::search_workspace(&root, &term, regex, case_sensitive);
            let _ = tx.send(report);
        });
    }

    fn execute(&mut self, action: Action, ctx: &egui::Context) {
        match action {
            Action::New => { self.add_empty(); self.persist(); }
            Action::OpenDialog => {
                let mut dialog = rfd::FileDialog::new().set_title("Open text or source file");
                if let Some(root) = &self.workspace { dialog = dialog.set_directory(root); }
                if let Some(paths) = dialog.pick_files() { for path in paths { self.open_file(path); } }
            }
            Action::OpenFile(path) => self.open_file(path),
            Action::OpenFolder => {
                if let Some(path) = rfd::FileDialog::new().set_title("Open workspace folder").pick_folder() {
                    self.workspace = Some(path); self.persist();
                }
            }
            Action::Save => { self.save_active(false, false); }
            Action::SaveAs => { self.save_active(true, true); }
            Action::SaveAll => self.save_all(),
            Action::SaveForce => { self.save_active(false, true); }
            Action::Close(id) => self.close_doc(id),
            Action::Select(index) => {
                if index < self.docs.len() { self.active = index; self.cursor_char = 0; self.clear_search(); self.refresh_search(); }
            }
            Action::RefreshSearch => { self.find.selected=0; self.refresh_search(); self.select_match(); }
            Action::FindNext(forwards) => self.jump_match(forwards),
            Action::ReplaceOne => self.replace_one(),
            Action::ReplaceAll => self.replace_all(),
            Action::Goto(line) => self.jump_to_line(line),
            Action::ToggleFind => { self.find.open = true; self.refresh_search(); }
            Action::ToggleGoto => { self.goto_open = !self.goto_open; }
            Action::TogglePreview => { self.show_preview = !self.show_preview; }
            Action::ToggleExplorer => { self.show_explorer = !self.show_explorer; self.persist(); }
            Action::ComponentsSettings => { self.components_open = true; }
            Action::JsonPretty | Action::JsonCompact | Action::TrimTrailingWhitespace | Action::SortLines => self.transform_text(&action),
            Action::Cargo(which) => self.run_cargo(which),
            Action::ToggleTheme => {
                self.dark = !self.dark;
                components::theme::apply(ctx, self.dark);
            }
            Action::FontSize(change) => self.font_size = (self.font_size + change).clamp(10.0, 28.0),
            Action::SearchWorkspace => self.run_workspace_search(),
            Action::OpenAt(path, line) => {
                let canonical = fs::canonicalize(&path).unwrap_or(path);
                self.open_file(canonical.clone());
                if self.active_doc().and_then(|d| d.path.as_ref()) == Some(&canonical) {
                    self.jump_to_line(line);
                }
            },
            Action::ReloadFile => {
                if let Some(doc) = self.active_doc() {
                    if doc.dirty { self.show_error("Save or close the modified tab before reloading from disk"); }
                    else if let Some(path) = doc.path.clone() {
                        let id = doc.id;
                        match Document::from_file(id, path) {
                            Ok(new_doc) => { self.docs[self.active] = new_doc; self.refresh_search(); }
                            Err(err) => self.show_error(err),
                        }
                    }
                }
            }
            Action::ShowHelp => { self.show_help = true; }
            Action::ToggleAi => self.ai.visible = !self.ai.visible,
            Action::AiSettings => self.ai.settings_open = true,
        }
        ctx.request_repaint();
    }

    fn collect_shortcuts(&self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        ctx.input(|i| {
            let ctrl = i.modifiers.ctrl || i.modifiers.command;
            if ctrl && i.key_pressed(Key::N) { actions.push(Action::New); }
            if ctrl && i.key_pressed(Key::O) { actions.push(Action::OpenDialog); }
            if ctrl && i.key_pressed(Key::S) {
                actions.push(if i.modifiers.shift { Action::SaveAs } else { Action::Save });
            }
            if ctrl && i.key_pressed(Key::W) {
                if let Some(doc) = self.active_doc() { actions.push(Action::Close(doc.id)); }
            }
            if ctrl && i.key_pressed(Key::F) { actions.push(Action::ToggleFind); }
            if ctrl && i.key_pressed(Key::H) { actions.push(Action::ToggleFind); }
            if ctrl && i.key_pressed(Key::G) { actions.push(Action::ToggleGoto); }
            if ctrl && i.key_pressed(Key::Equals) { actions.push(Action::FontSize(1.0)); }
            if ctrl && i.key_pressed(Key::Minus) { actions.push(Action::FontSize(-1.0)); }
            if i.key_pressed(Key::F3) { actions.push(Action::FindNext(!i.modifiers.shift)); }
        });
    }

}
impl Drop for EditorApp {
    fn drop(&mut self) { self.persist(); }
}

impl eframe::App for EditorApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.ai.poll();
        while let Ok(result) = self.task_rx.try_recv() {
            self.task_running = false;
            self.console.push_str(&format!("\n=== {} ===\n{}\n", result.title, result.output));
            self.status = format!("{} finished", result.title);
        }
        while let Ok(report) = self.search_rx.try_recv() {
            self.workspace_search_running = false;
            self.workspace_search_summary = if let Some(error) = report.error {
                format!("Workspace search error: {error}")
            } else {
                format!("Workspace: {} hits, {} files scanned, {} skipped (limit 1,000 hits)",
                    report.hits.len(), report.visited, report.skipped)
            };
            self.workspace_hits = report.hits;
        }
        let mut actions = Vec::new();
        self.collect_shortcuts(ctx, &mut actions);
        let drops: Vec<PathBuf> = ctx.input(|i| i.raw.dropped_files.iter().filter_map(|f| f.path.clone()).collect());
        for path in drops { actions.push(Action::OpenFile(path)); }
        components::draw(self, ctx, &mut actions);
        for action in actions { self.execute(action, ctx); }
        if self.last_recovery.elapsed() >= Duration::from_secs(15) {
            self.persist(); self.last_recovery = Instant::now();
        }
        ctx.request_repaint_after(Duration::from_millis(300));
    }
}

#[cfg(test)]
mod component_state_tests {
    use super::*;

    #[test]
    fn old_session_restores_without_component_preferences() {
        let old = r#"{"docs":[],"active":0,"workspace":null,"recent":[],"dark":true,"font_size":14.0}"#;
        let session: Session = serde_json::from_str(old).expect("old session format should be readable");
        assert!(session.show_explorer);
        assert!(!session.show_search);
        assert!(!session.show_preview);
        assert!(!session.show_console);
        assert!(!session.show_ai);
    }

    #[test]
    fn externally_deleted_document_is_not_silently_recreated() {
        let dir = std::env::temp_dir().join(format!("toneedit-external-delete-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        let path = dir.join("source.rs");
        fs::write(&path, "original").unwrap();
        let mut doc = Document::from_file(1, path.clone()).unwrap();
        fs::remove_file(&path).unwrap();
        doc.text = "new content".into();
        doc.dirty = true;
        assert!(doc.save(&path, false).is_err());
        assert!(!path.exists());
        assert!(doc.save(&path, true).is_ok());
        assert_eq!(fs::read_to_string(&path).unwrap(), "new content");
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn workbench_renders_in_headless_egui_context() {
        // No native window is required: exercise registration and layout of
        // every visible Rust component during cargo test.
        let ctx = egui::Context::default();
        let mut app = EditorApp::new(&ctx);
        app.state_path = std::env::temp_dir().join(format!("toneedit-render-test-{}.json", std::process::id()));
        let _ = ctx.run(egui::RawInput::default(), |ctx| {
            let mut actions = Vec::new();
            components::draw(&mut app, ctx, &mut actions);
        });
        assert!(!app.docs.is_empty());
        let path = app.state_path.clone();
        drop(app);
        let _ = fs::remove_file(path);
    }
}
