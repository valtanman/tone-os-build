//! Loss-aware disk I/O, newline handling, backups, and no-dependency atomic replacement.
//! All editor source code is Rust. No Python, JS, or external processes are used for I/O.
use encoding_rs::SHIFT_JIS;
use serde::{Deserialize, Serialize};
use std::fs::{self, File, OpenOptions};
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

/// The UI uses one TextEdit widget per document; unusually large inputs should use
/// a streaming viewer rather than attempting to render every line in one widget.
pub const MAX_EDITABLE_BYTES: u64 = 32 * 1024 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Encoding {
    Utf8,
    Utf8Bom,
    Utf16Le,
    Utf16Be,
    ShiftJis,
}
impl Encoding {
    pub const ALL: [Self; 5] = [Self::Utf8, Self::Utf8Bom, Self::Utf16Le, Self::Utf16Be, Self::ShiftJis];
    pub fn label(self) -> &'static str {
        match self {
            Self::Utf8 => "UTF-8",
            Self::Utf8Bom => "UTF-8 BOM",
            Self::Utf16Le => "UTF-16 LE",
            Self::Utf16Be => "UTF-16 BE",
            Self::ShiftJis => "Shift-JIS",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LineEnding {
    Lf,
    CrLf,
    Cr,
}
impl LineEnding {
    pub const ALL: [Self; 3] = [Self::Lf, Self::CrLf, Self::Cr];
    pub fn label(self) -> &'static str {
        match self { Self::Lf => "LF", Self::CrLf => "CRLF", Self::Cr => "CR" }
    }
    pub fn as_str(self) -> &'static str {
        match self { Self::Lf => "\n", Self::CrLf => "\r\n", Self::Cr => "\r" }
    }
}

#[derive(Debug, Clone)]
pub struct Decoded {
    pub text: String,
    pub encoding: Encoding,
    pub newline: LineEnding,
    pub mixed_newlines: bool,
}

fn utf16(bytes: &[u8], little: bool) -> Result<String, String> {
    if bytes.len() % 2 != 0 {
        return Err("UTF-16 file has an odd number of bytes".into());
    }
    let units: Vec<u16> = bytes.chunks_exact(2).map(|b| {
        if little { u16::from_le_bytes([b[0], b[1]]) } else { u16::from_be_bytes([b[0], b[1]]) }
    }).collect();
    String::from_utf16(&units).map_err(|_| "Invalid UTF-16 sequence".to_owned())
}

/// Decode without lossy substitution; refuse uncertain binary/invalid contents.
/// Legacy files without BOM are assumed to be Shift-JIS only when strict UTF-8 fails.
pub fn decode_bytes(bytes: &[u8]) -> Result<Decoded, String> {
    let (raw, encoding) = if bytes.starts_with(&[0xEF, 0xBB, 0xBF]) {
        (std::str::from_utf8(&bytes[3..]).map_err(|e| e.to_string())?.to_owned(), Encoding::Utf8Bom)
    } else if bytes.starts_with(&[0xFF, 0xFE]) {
        (utf16(&bytes[2..], true)?, Encoding::Utf16Le)
    } else if bytes.starts_with(&[0xFE, 0xFF]) {
        (utf16(&bytes[2..], false)?, Encoding::Utf16Be)
    } else if let Ok(s) = std::str::from_utf8(bytes) {
        (s.to_owned(), Encoding::Utf8)
    } else {
        if bytes.contains(&0) { return Err("NUL bytes detected: this may be a binary file".into()); }
        let (decoded, has_errors) = SHIFT_JIS.decode_without_bom_handling(bytes);
        if has_errors {
            return Err("Invalid UTF-8 / Shift-JIS. Refusing to replace undecodable bytes".into());
        }
        (decoded.into_owned(), Encoding::ShiftJis)
    };
    if raw.contains('\0') { return Err("NUL bytes detected: use a HEX editor for binary files".into()); }
    let crlf = raw.matches("\r\n").count();
    let lone_lf = raw.as_bytes().iter().enumerate().filter(|(i, b)| **b == b'\n' && (*i == 0 || raw.as_bytes()[*i - 1] != b'\r')).count();
    let lone_cr = raw.as_bytes().iter().enumerate().filter(|(i, b)| **b == b'\r' && raw.as_bytes().get(*i + 1) != Some(&b'\n')).count();
    let mut distinct = 0;
    for count in [crlf, lone_lf, lone_cr] { if count > 0 { distinct += 1; } }
    let newline = if crlf >= lone_lf && crlf >= lone_cr && crlf > 0 {
        LineEnding::CrLf
    } else if lone_cr > lone_lf { LineEnding::Cr } else { LineEnding::Lf };
    Ok(Decoded { text: raw.replace("\r\n", "\n").replace('\r', "\n"), encoding, newline, mixed_newlines: distinct > 1 })
}

pub fn encode_text(text: &str, encoding: Encoding, newline: LineEnding) -> Result<Vec<u8>, String> {
    let normalized = text.replace("\r\n", "\n").replace('\r', "\n");
    let output = if newline == LineEnding::Lf { normalized } else { normalized.replace('\n', newline.as_str()) };
    match encoding {
        Encoding::Utf8 => Ok(output.into_bytes()),
        Encoding::Utf8Bom => {
            let mut bytes = vec![0xEF, 0xBB, 0xBF]; bytes.extend(output.as_bytes()); Ok(bytes)
        }
        Encoding::Utf16Le | Encoding::Utf16Be => {
            let le = encoding == Encoding::Utf16Le;
            let mut bytes = if le { vec![0xFF, 0xFE] } else { vec![0xFE, 0xFF] };
            for unit in output.encode_utf16() {
                let pair = if le { unit.to_le_bytes() } else { unit.to_be_bytes() };
                bytes.extend_from_slice(&pair);
            }
            Ok(bytes)
        }
        Encoding::ShiftJis => {
            let (bytes, _, had_errors) = SHIFT_JIS.encode(&output);
            if had_errors { Err("Some characters cannot be represented in Shift-JIS. Choose UTF-8 before saving".into()) }
            else { Ok(bytes.into_owned()) }
        }
    }
}

pub fn load(path: &Path) -> Result<Decoded, String> {
    let len = fs::metadata(path).map_err(|e| format!("Cannot inspect file: {e}"))?.len();
    if len > MAX_EDITABLE_BYTES {
        return Err(format!("File is {:.1} MiB; the current editor safely limits editable files to 32 MiB", len as f64 / 1048576.0));
    }
    decode_bytes(&fs::read(path).map_err(|e| format!("Cannot read file: {e}"))?)
}

pub fn file_modification(path: &Path) -> Option<SystemTime> {
    fs::metadata(path).ok()?.modified().ok()
}

pub fn backup_path(path: &Path) -> PathBuf {
    let mut name = path.as_os_str().to_os_string();
    name.push(".toneedit.bak");
    PathBuf::from(name)
}

pub fn save(path: &Path, text: &str, encoding: Encoding, newline: LineEnding) -> Result<(), String> {
    let bytes = encode_text(text, encoding, newline)?;
    let dir = path.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or(Path::new("."));
    let stamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos();
    let filename = path.file_name().ok_or("Cannot determine file name")?.to_string_lossy();
    let tmp_path = dir.join(format!(".{filename}.toneedit-{}-{stamp}.tmp", std::process::id()));
    {
        let mut f = OpenOptions::new().write(true).create_new(true).open(&tmp_path)
            .map_err(|e| format!("Cannot create temporary file: {e}"))?;
        if let Err(e) = f.write_all(&bytes).and_then(|_| f.sync_all()) {
            let _ = fs::remove_file(&tmp_path);
            return Err(format!("Cannot write temporary file: {e}"));
        }
    }
    if path.exists() {
        if let Err(e) = fs::copy(path, backup_path(path)) {
            let _ = fs::remove_file(&tmp_path);
            return Err(format!("Cannot write .toneedit.bak backup: {e}"));
        }
    }
    if let Err(e) = replace_atomically(&tmp_path, path) {
        let _ = fs::remove_file(&tmp_path);
        return Err(format!("Cannot replace original file: {e}. Original or backup was kept"));
    }
    Ok(())
}

#[cfg(windows)]
fn replace_atomically(tmp: &Path, target: &Path) -> io::Result<()> {
    use std::os::windows::ffi::OsStrExt;
    #[link(name = "kernel32")]
    extern "system" {
        fn MoveFileExW(old: *const u16, new: *const u16, flags: u32) -> i32;
    }
    let wide = |p: &Path| p.as_os_str().encode_wide().chain(std::iter::once(0)).collect::<Vec<u16>>();
    let a = wide(tmp); let b = wide(target);
    const REPLACE_EXISTING: u32 = 0x0000_0001;
    const WRITE_THROUGH: u32 = 0x0000_0008;
    let ok = unsafe { MoveFileExW(a.as_ptr(), b.as_ptr(), REPLACE_EXISTING | WRITE_THROUGH) };
    if ok == 0 { Err(io::Error::last_os_error()) } else { Ok(()) }
}
#[cfg(not(windows))]
fn replace_atomically(tmp: &Path, target: &Path) -> io::Result<()> { fs::rename(tmp, target) }

/// Atomically persist app state (autosave data); the source file remains untouched.
pub fn save_state(path: &Path, json: &str) -> Result<(), String> {
    if let Some(parent) = path.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    let temp = path.with_extension("tmp");
    let mut file = File::create(&temp).map_err(|e| e.to_string())?;
    file.write_all(json.as_bytes()).and_then(|_| file.sync_all()).map_err(|e| e.to_string())?;
    replace_atomically(&temp, path).map_err(|e| e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn roundtrip_utf8_bom_crlf() {
        let bytes = encode_text("a\nあ\n", Encoding::Utf8Bom, LineEnding::CrLf).unwrap();
        assert!(bytes.starts_with(&[0xef, 0xbb, 0xbf]));
        assert_eq!(decode_bytes(&bytes).unwrap().text, "a\nあ\n");
        assert_eq!(decode_bytes(&bytes).unwrap().newline, LineEnding::CrLf);
    }
    #[test] fn roundtrip_utf16() {
        for enc in [Encoding::Utf16Le, Encoding::Utf16Be] {
            let bytes = encode_text("日本語\n🌸", enc, LineEnding::Lf).unwrap();
            let result = decode_bytes(&bytes).unwrap();
            assert_eq!(result.text, "日本語\n🌸");
            assert_eq!(result.encoding, enc);
        }
    }
    #[test] fn shift_jis_no_silent_substitution() {
        assert!(encode_text("abc🌸", Encoding::ShiftJis, LineEnding::CrLf).is_err());
        let bytes = encode_text("こんにちは\n", Encoding::ShiftJis, LineEnding::CrLf).unwrap();
        assert_eq!(decode_bytes(&bytes).unwrap().text, "こんにちは\n");
    }
    #[test] fn newline_detection() {
        let sample = decode_bytes(b"a\rb\rc").unwrap();
        assert_eq!(sample.newline, LineEnding::Cr);
        assert_eq!(sample.text, "a\nb\nc");
        let mixed = decode_bytes(b"a\r\nb\nc").unwrap();
        assert!(mixed.mixed_newlines);
    }
    #[test] fn binary_rejection() { assert!(decode_bytes(b"a\0b").is_err()); }
    #[test] fn filesystem_backup() {
        let dir = std::env::temp_dir().join(format!("toneedit-test-{}-{}", std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()));
        fs::create_dir_all(&dir).unwrap();
        let path = dir.join("test.txt");
        save(&path, "first", Encoding::Utf8, LineEnding::Lf).unwrap();
        save(&path, "second", Encoding::Utf8, LineEnding::Lf).unwrap();
        assert_eq!(fs::read_to_string(&path).unwrap(), "second");
        assert_eq!(fs::read_to_string(backup_path(&path)).unwrap(), "first");
        fs::remove_dir_all(dir).unwrap();
    }
}
