//! Vendor-neutral, text-only AI chat. No bundled identity, system persona, passwords or API keys.
//! API keys/tokens reside in the operating system credential vault via `keyring`.
use eframe::egui::{self, Color32, RichText};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::path::PathBuf;
use std::io::Read;
use std::sync::mpsc::{self, Receiver, Sender};
use std::thread;
use std::time::Duration;

use crate::google_oauth::{self, GoogleLoginResult};
mod providers;

const SERVICE: &str = "ToneEdit Studio";
const MAX_MESSAGE_BYTES: usize = 64 * 1024;
const MAX_REPLY_BYTES: usize = 2 * 1024 * 1024;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum Vendor {
    OpenAi, Anthropic, Gemini, XAi, DeepSeek, Mistral, Groq, OpenRouter,
    Together, Perplexity, Ollama, Custom,
}
impl Vendor {
    pub const ALL: [Self; 12] = [Self::OpenAi, Self::Anthropic, Self::Gemini, Self::XAi,
        Self::DeepSeek, Self::Mistral, Self::Groq, Self::OpenRouter,
        Self::Together, Self::Perplexity, Self::Ollama, Self::Custom];
    pub fn label(self) -> &'static str {
        match self { Self::OpenAi => "OpenAI", Self::Anthropic => "Anthropic Claude",
            Self::Gemini => "Google Gemini", Self::XAi => "xAI Grok",
            Self::DeepSeek => "DeepSeek", Self::Mistral => "Mistral",
            Self::Groq => "Groq", Self::OpenRouter => "OpenRouter",
            Self::Together => "Together AI", Self::Perplexity => "Perplexity",
            Self::Ollama => "Ollama (local)", Self::Custom => "Custom OpenAI-compatible" }
    }
    pub fn id(self) -> &'static str {
        match self { Self::OpenAi => "openai", Self::Anthropic => "anthropic",
            Self::Gemini => "gemini", Self::XAi => "xai", Self::DeepSeek => "deepseek",
            Self::Mistral => "mistral", Self::Groq => "groq", Self::OpenRouter => "openrouter",
            Self::Together => "together", Self::Perplexity => "perplexity",
            Self::Ollama => "ollama", Self::Custom => "custom" }
    }
    pub fn default_model(self) -> &'static str {
        match self { Self::OpenAi => "gpt-4.1-mini", Self::Anthropic => "claude-sonnet-4-5",
            Self::Gemini => "gemini-2.5-flash", Self::XAi => "grok-3-mini",
            Self::DeepSeek => "deepseek-chat", Self::Mistral => "mistral-small-latest",
            Self::Groq => "llama-3.3-70b-versatile", Self::OpenRouter => "openai/gpt-4.1-mini",
            Self::Together => "meta-llama/Llama-3.3-70B-Instruct-Turbo",
            Self::Perplexity => "sonar", Self::Ollama => "llama3.2", Self::Custom => "my-model" }
    }
    pub fn default_endpoint(self) -> &'static str {
        match self {
            Self::OpenAi => "https://api.openai.com/v1/chat/completions",
            Self::Anthropic => "https://api.anthropic.com/v1/messages",
            Self::Gemini => "https://generativelanguage.googleapis.com/v1beta",
            Self::XAi => "https://api.x.ai/v1/chat/completions",
            Self::DeepSeek => "https://api.deepseek.com/chat/completions",
            Self::Mistral => "https://api.mistral.ai/v1/chat/completions",
            Self::Groq => "https://api.groq.com/openai/v1/chat/completions",
            Self::OpenRouter => "https://openrouter.ai/api/v1/chat/completions",
            Self::Together => "https://api.together.xyz/v1/chat/completions",
            Self::Perplexity => "https://api.perplexity.ai/chat/completions",
            Self::Ollama => "http://127.0.0.1:11434/v1/chat/completions",
            Self::Custom => "https://example.invalid/v1/chat/completions",
        }
    }
    pub fn requires_key(self) -> bool { !matches!(self, Self::Ollama) }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Message { pub role: String, pub content: String }
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Conversation {
    id: u64,
    title: String,
    provider: Vendor,
    model: String,
    #[serde(default)]
    endpoint: Option<String>,
    messages: Vec<Message>,
}
#[derive(Serialize, Deserialize)]
#[serde(default)]
struct ChatFile {
    vendor: Vendor,
    model: String,
    custom_url: String,
    google_oauth_client_id: String,
    system_instructions: String,
    conversations: Vec<Conversation>,
    current: u64,
    next_id: u64,
    /// Account identifiers, passwords, access tokens and API keys are deliberately absent.
}
impl Default for ChatFile {
    fn default() -> Self { Self {
        vendor: Vendor::OpenAi, model: Vendor::OpenAi.default_model().into(),
        custom_url: Vendor::Custom.default_endpoint().into(), google_oauth_client_id: String::new(),
        system_instructions: String::new(), conversations: vec![], current: 0, next_id: 1,
    } }
}
struct Reply { id: u64, text: Result<String, String> }

pub struct AiWorkspace {
    pub visible: bool,
    pub settings_open: bool,
    data: ChatFile,
    path: PathBuf,
    prompt: String,
    api_key_input: String,
    google_client_secret_input: String,
    status: String,
    pending: Option<u64>,
    tx: Sender<Reply>,
    rx: Receiver<Reply>,
    google_tx: Sender<GoogleLoginResult>,
    google_rx: Receiver<GoogleLoginResult>,
    google_status: String,
    delete_confirm: Option<u64>,
}

impl AiWorkspace {
    pub fn new() -> Self {
        let mut path = super::default_state_path();
        path.set_file_name("ai_chat.json");
        let data = std::fs::read_to_string(&path).ok()
            .and_then(|s| serde_json::from_str::<ChatFile>(&s).ok()).unwrap_or_default();
        let (tx, rx) = mpsc::channel();
        let (google_tx, google_rx) = mpsc::channel();
        Self { visible: false, settings_open: false, data, path,
            prompt: String::new(), api_key_input: String::new(),
            google_client_secret_input: String::new(), status: String::new(),
            pending: None, tx, rx, google_tx, google_rx,
            google_status: "Google account is not signed in for this session".into(),
            delete_confirm: None }
    }
    fn save(&mut self) {
        if let Ok(content) = serde_json::to_string_pretty(&self.data) {
            if let Err(e) = super::document::save_state(&self.path, &content) {
                self.status = format!("Chat history save failed: {e}");
            }
        }
    }
    fn create_chat(&mut self) {
        let id = self.data.next_id;
        self.data.next_id += 1;
        self.data.conversations.push(Conversation { id, title: "New conversation".into(),
            provider: self.data.vendor, model: self.data.model.clone(),
            endpoint: None, messages: vec![] });
        self.data.current = id;
        self.save();
    }
    fn active_chat(&self) -> Option<&Conversation> {
        self.data.conversations.iter().find(|c| c.id == self.data.current)
    }
    fn active_chat_mut(&mut self) -> Option<&mut Conversation> {
        self.data.conversations.iter_mut().find(|c| c.id == self.data.current)
    }
    fn provider_secret(&self) -> Result<String, String> {
        if !self.data.vendor.requires_key() { return Ok(String::new()); }
        credential_entry(self.data.vendor).and_then(|e| e.get_password().map_err(|e| format!("Credential not available: {e}")))
    }
    fn send(&mut self) {
        if self.pending.is_some() || self.prompt.trim().is_empty() { return; }
        if self.prompt.len() > MAX_MESSAGE_BYTES { self.status = "Prompt exceeds 64 KiB limit".into(); return; }
        let key = match self.provider_secret() {
            Ok(k) => k,
            Err(e) => { self.status = format!("Set an API key in AI > Connections. {e}"); self.settings_open = true; return; }
        };
        let vendor = self.data.vendor;
        let model = self.data.model.trim().to_string();
        if model.is_empty() { self.status = "Set a model name in Connections".into(); return; }
        let endpoint = if vendor == Vendor::Custom { self.data.custom_url.trim().to_owned() }
                       else { vendor.default_endpoint().to_owned() };
        if let Err(e) = validate_endpoint(vendor, &endpoint) { self.status = e; return; }
        if self.active_chat().is_some_and(|c| c.messages.len() >= 100 && c.provider == vendor) {
            self.status = "Conversation limit reached (100 messages). Start a new chat.".into();
            return;
        }
        // A provider change is a new conversation. Never silently send a previous
        // provider's chat history to a different vendor.
        if self.active_chat().is_some_and(|c| !c.messages.is_empty() &&
            (c.provider != vendor || (vendor == Vendor::Custom && c.endpoint.as_deref() != Some(endpoint.as_str())))) {
            self.create_chat();
            self.status = "Destination changed: started a separate conversation to protect history.".into();
        }
        if self.active_chat().is_none() { self.create_chat(); }
        let prompt = self.prompt.trim().to_owned();
        let instruction = self.data.system_instructions.clone();
        let chat = self.active_chat_mut().expect("chat created");
        chat.provider = vendor;
        chat.model = model.clone();
        chat.endpoint = if vendor == Vendor::Custom { Some(endpoint.clone()) } else { None };
        if chat.messages.is_empty() { chat.title = prompt.chars().take(45).collect(); }
        chat.messages.push(Message { role: "user".into(), content: prompt });
        let messages = chat.messages.clone();
        let id = chat.id;
        self.pending = Some(id);
        self.status = "Sending only this conversation to the selected AI provider...".into();
        self.prompt.clear();
        self.save();
        let sender = self.tx.clone();
        thread::spawn(move || {
            let result = request_chat(vendor, &endpoint, &model, &key, &instruction, &messages);
            let _ = sender.send(Reply { id, text: result });
        });
    }
    fn attach_text_file(&mut self) {
        let Some(path) = rfd::FileDialog::new().set_title("Attach text file to the draft (not sent automatically)").pick_file() else {
            return;
        };
        match std::fs::metadata(&path) {
            Ok(metadata) if metadata.len() <= 24 * 1024 => {
                match super::document::load(&path) {
                    Ok(decoded) => {
                        let label = path.file_name().unwrap_or_default().to_string_lossy();
                        let snippet = format!("\n\nAttached text file: {label}\n```text\n{}\n```\n", decoded.text);
                        if self.prompt.len() + snippet.len() > MAX_MESSAGE_BYTES {
                            self.status = "Attachment would exceed 64 KiB prompt limit".into();
                        } else {
                            self.prompt.push_str(&snippet);
                            self.status = "File inserted into draft. Review before pressing Send.".into();
                        }
                    }
                    Err(e) => self.status = format!("Could not read attachment: {e}"),
                }
            }
            Ok(_) => self.status = "Text attachments are limited to 24 KiB".into(),
            Err(e) => self.status = format!("Could not inspect selected file: {e}"),
        }
    }
    fn export_conversation(&mut self) {
        let Some(chat) = self.active_chat() else {
            self.status = "No conversation selected".into(); return;
        };
        let mut markdown = format!("# {}\n\nProvider: {}\nModel: {}\n\n",
            chat.title, chat.provider.label(), chat.model);
        for msg in &chat.messages {
            markdown.push_str(&format!("## {}\n\n{}\n\n", msg.role, msg.content));
        }
        let Some(path) = rfd::FileDialog::new().set_title("Export AI chat as Markdown")
            .set_file_name("toneedit-chat.md").save_file() else { return; };
        self.status = match std::fs::write(path, markdown) {
            Ok(()) => "Conversation exported".into(),
            Err(e) => format!("Could not export chat: {e}"),
        };
    }
    pub fn poll(&mut self) {
        while let Ok(reply) = self.rx.try_recv() {
            if self.pending != Some(reply.id) { continue; }
            self.pending = None;
            match reply.text {
                Ok(content) => {
                    if let Some(c) = self.data.conversations.iter_mut().find(|c| c.id == reply.id) {
                        c.messages.push(Message { role: "assistant".into(), content });
                    }
                    self.status = "Answer received".into();
                    self.save();
                }
                Err(e) => self.status = e,
            }
        }
        while let Ok(response) = self.google_rx.try_recv() {
            match response {
                Ok(email) => self.google_status = format!("Connected to Google: {email}"),
                Err(err) => self.google_status = format!("Google sign-in failed: {err}"),
            }
        }
    }
    pub fn show(&mut self, ctx: &egui::Context) -> Option<String> {
        if !self.visible { return None; }
        let mut insert = None;
        egui::SidePanel::right("toneedit-ai-chat").resizable(true)
            .default_width(465.0).min_width(300.0).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.heading("AI CHAT");
                if ui.small_button("Connections").clicked() { self.settings_open = true; }
                if ui.small_button("×").clicked() { self.visible = false; }
            });
            ui.label(RichText::new("No fixed persona. Each provider uses its own API and billing.").small().weak());
            ui.horizontal(|ui| {
                egui::ComboBox::from_id_salt("ai_provider")
                    .selected_text(self.data.vendor.label()).show_ui(ui, |ui| {
                        for vendor in Vendor::ALL {
                            if ui.selectable_value(&mut self.data.vendor, vendor, vendor.label()).changed() {
                                self.data.model = vendor.default_model().into(); self.save();
                            }
                        }
                    });
                if ui.button("+ New").clicked() { self.create_chat(); }
            });
            ui.horizontal(|ui| {
                ui.label("Model");
                if ui.text_edit_singleline(&mut self.data.model).changed() { self.save(); }
            });
            ui.separator();
            ui.collapsing("Conversations", |ui| {
                let items: Vec<(u64, String)> = self.data.conversations.iter().rev()
                    .map(|c| (c.id, c.title.clone())).collect();
                for (id, title) in items {
                    ui.horizontal(|ui| {
                        if ui.selectable_label(self.data.current == id, title).clicked() {
                            self.data.current = id;
                            if let Some((vendor, model, endpoint)) = self.active_chat()
                                .map(|c| (c.provider, c.model.clone(), c.endpoint.clone())) {
                                self.data.vendor = vendor;
                                self.data.model = model;
                                if vendor == Vendor::Custom {
                                    if let Some(endpoint) = endpoint { self.data.custom_url = endpoint; }
                                }
                            }
                            self.save();
                        }
                        if ui.small_button("Delete").clicked() { self.delete_confirm = Some(id); }
                    });
                }
            });
            if ui.button("Export selected conversation (.md)").clicked() { self.export_conversation(); }
            ui.separator();
            let newest = self.active_chat().and_then(|chat| chat.messages.last())
                .filter(|m| m.role == "assistant").map(|m| m.content.clone());
            ui.horizontal(|ui| {
                if let Some(reply) = &newest {
                    if ui.button("Insert answer into editor").clicked() { insert = Some(reply.clone()); }
                    if ui.button("Copy answer").clicked() { ui.ctx().copy_text(reply.clone()); }
                }
            });
            egui::ScrollArea::vertical().id_salt("chat-messages").stick_to_bottom(true)
                .max_height((ui.available_height() - 180.0).max(150.0)).show(ui, |ui| {
                if let Some(chat) = self.active_chat() {
                    for msg in &chat.messages {
                        let (label, color) = if msg.role == "user" {
                            ("YOU", Color32::from_rgb(114, 192, 245))
                        } else { ("ASSISTANT", Color32::from_rgb(187, 155, 255)) };
                        ui.label(RichText::new(label).strong().color(color));
                        ui.label(&msg.content);
                        ui.add_space(10.0);
                        ui.separator();
                    }
                }
            });
            ui.separator();
            ui.add(egui::TextEdit::multiline(&mut self.prompt)
                .hint_text("Ask a question. Only send when you click Send.")
                .desired_rows(4).desired_width(f32::INFINITY));
            ui.horizontal(|ui| {
                if ui.button("Attach text...").clicked() { self.attach_text_file(); }
                if self.pending.is_some() { ui.spinner(); }
                if ui.add_enabled(self.pending.is_none() && !self.prompt.trim().is_empty(),
                    egui::Button::new("Send message")).clicked() { self.send(); }
                ui.label(RichText::new(format!("{} / 65536 bytes", self.prompt.len())).small().weak());
            });
            if !self.status.is_empty() { ui.label(RichText::new(&self.status).small().color(Color32::LIGHT_YELLOW)); }
            ui.label(RichText::new("Chats are kept locally as plaintext; API keys are in OS credentials. No analytics.")
                .small().weak());
        });
        insert
    }
    pub fn settings_ui(&mut self, ctx: &egui::Context) {
        if !self.settings_open { return; }
        let mut open = self.settings_open;
        egui::Window::new("AI Connections — ToneEdit Studio")
            .open(&mut open).min_width(560.0).default_width(620.0).show(ctx, |ui| {
            ui.heading("AI providers / API credentials");
            ui.label("Select a vendor and model. Enter an API key provided by that vendor.");
            egui::ComboBox::from_id_salt("settings_vendor")
                .selected_text(self.data.vendor.label()).show_ui(ui, |ui| {
                    for vendor in Vendor::ALL {
                        if ui.selectable_value(&mut self.data.vendor, vendor, vendor.label()).changed() {
                            self.data.model = vendor.default_model().into(); self.save();
                        }
                    }
                });
            ui.horizontal(|ui| { ui.label("Model name:"); ui.text_edit_singleline(&mut self.data.model); });
            if self.data.vendor == Vendor::Custom {
                ui.label("Custom HTTPS chat-completions URL:");
                ui.text_edit_singleline(&mut self.data.custom_url);
                ui.label(RichText::new("A custom server receives your API key and messages. Only use trusted HTTPS servers.").small().weak());
            }
            ui.label(format!("Endpoint: {}", if self.data.vendor == Vendor::Custom {
                self.data.custom_url.as_str() } else { self.data.vendor.default_endpoint() }));
            if self.data.vendor.requires_key() {
                ui.separator();
                ui.label("API key (stored in operating-system credential manager, not chat history):");
                ui.add(egui::TextEdit::singleline(&mut self.api_key_input).password(true).desired_width(400.0));
                ui.horizontal(|ui| {
                    if ui.button("Save API key").clicked() {
                        let key = self.api_key_input.trim();
                        if key.is_empty() { self.status = "Please enter an API key".into(); }
                        else {
                            self.status = match credential_entry(self.data.vendor)
                                .and_then(|entry| entry.set_password(key).map_err(|e| e.to_string())) {
                                Ok(()) => "API key stored securely".into(),
                                Err(e) => format!("Could not store API key: {e}"),
                            };
                            self.api_key_input.clear();
                        }
                    }
                    if ui.button("Remove saved API key").clicked() {
                        self.status = match credential_entry(self.data.vendor)
                            .and_then(|entry| entry.delete_credential().map_err(|e| e.to_string())) {
                            Ok(()) => "API key removed".into(), Err(e) => format!("Removal: {e}"),
                        };
                        self.api_key_input.clear();
                    }
                });
            } else { ui.label("Local Ollama does not require a cloud API key."); }
            ui.separator();
            ui.heading("Optional instructions");
            ui.label("Empty by default. No user persona or built-in identity profile.");
            ui.add(egui::TextEdit::multiline(&mut self.data.system_instructions).desired_rows(3));
            ui.separator();
            ui.heading("Google account (OAuth 2.0 + PKCE)");
            ui.label("Google login is separate from Gemini API keys. No Google password is collected.");
            ui.label("Google Cloud desktop OAuth client ID (provided by the user):");
            ui.text_edit_singleline(&mut self.data.google_oauth_client_id);
            ui.label("Google desktop OAuth client secret (if required, kept in OS vault):");
            ui.add(egui::TextEdit::singleline(&mut self.google_client_secret_input).password(true));
            if ui.button("Save OAuth client secret").clicked() {
                self.google_status = match google_oauth::save_client_secret(&self.google_client_secret_input) {
                    Ok(()) => "Google OAuth client secret saved to OS credentials".into(),
                    Err(e) => e,
                };
                self.google_client_secret_input.clear();
            }
            ui.horizontal(|ui| {
                if ui.button("Sign in with Google").clicked() {
                    let result = google_oauth::start(&self.data.google_oauth_client_id, self.google_tx.clone());
                    match result {
                        Ok(url) => {
                            ctx.open_url(egui::OpenUrl { url, new_tab: true });
                            self.google_status = "Waiting for Google authorization in browser...".into();
                        }
                        Err(e) => self.google_status = e,
                    }
                }
                if ui.button("Disconnect Google").clicked() {
                    self.google_status = match google_oauth::disconnect() {
                        Ok(()) => "Google token removed from credential store".into(),
                        Err(e) => e,
                    };
                }
            });
            ui.label(RichText::new(&self.google_status).small());
            ui.separator();
            if ui.button("Save non-secret connection preferences").clicked() {
                self.save(); self.status = "Connection preferences saved".into();
            }
            ui.label(RichText::new("Vendor account passwords must be entered only on the vendor's own website. Some web-app features are not available via API.").small().weak());
            if !self.status.is_empty() { ui.label(RichText::new(&self.status).small()); }
        });
        self.settings_open = open;
    }
    pub fn confirm_delete_ui(&mut self, ctx: &egui::Context) {
        let Some(id) = self.delete_confirm else { return; };
        egui::Window::new("Delete chat history?").collapsible(false)
            .anchor(egui::Align2::CENTER_CENTER, [0., 0.]).show(ctx, |ui| {
            ui.label("This removes the selected local conversation, not the provider's account history.");
            ui.horizontal(|ui| {
                if ui.button("Delete conversation").clicked() {
                    self.data.conversations.retain(|c| c.id != id);
                    if self.data.current == id { self.data.current = 0; }
                    self.delete_confirm = None; self.save();
                }
                if ui.button("Cancel").clicked() { self.delete_confirm = None; }
            });
        });
    }
}

fn credential_entry(vendor: Vendor) -> Result<keyring::Entry, String> {
    keyring::Entry::new(SERVICE, &format!("provider.{}.api_key", vendor.id())).map_err(|e| e.to_string())
}

fn validate_endpoint(vendor: Vendor, endpoint: &str) -> Result<(), String> {
    let parsed = reqwest::Url::parse(endpoint).map_err(|_| "Invalid API endpoint URL".to_string())?;
    if vendor == Vendor::Ollama {
        let host = parsed.host_str().unwrap_or("");
        if !((host == "localhost" || host == "127.0.0.1" || host == "[::1]")
            && parsed.scheme() == "http") {
            return Err("Local Ollama must use an HTTP loopback address".into());
        }
    } else if parsed.scheme() != "https" {
        return Err("API keys are only sent over HTTPS".into());
    }
    if !parsed.username().is_empty() || parsed.password().is_some() {
        return Err("Do not put credentials in the endpoint URL".into());
    }
    Ok(())
}
fn make_request(vendor: Vendor, model: &str, system: &str, msgs: &[Message]) -> Value {
    providers::adapter(vendor).format_request(model, system, msgs)
}
fn parse_answer(vendor: Vendor, response: &Value) -> Result<String, String> {
    let content = providers::adapter(vendor).extract_text(response)
        .filter(|s| !s.trim().is_empty())
        .ok_or_else(|| "The provider returned no text reply. Check model/provider compatibility.".to_owned())?;
    if content.len() > MAX_REPLY_BYTES { return Err("Reply too large; rejected for safe storage".into()); }
    Ok(content)
}
fn request_chat(vendor: Vendor, endpoint: &str, model: &str, key: &str,
                system: &str, messages: &[Message]) -> Result<String, String> {
    validate_endpoint(vendor, endpoint)?;
    if messages.iter().any(|m| m.content.len() > MAX_MESSAGE_BYTES) {
        return Err("A message is larger than 64 KiB".into());
    }
    if messages.len() > 100 { return Err("Conversation exceeds 100 messages. Start a new chat.".into()); }
    let client = reqwest::blocking::Client::builder().connect_timeout(Duration::from_secs(10))
        .timeout(Duration::from_secs(120)).redirect(reqwest::redirect::Policy::none())
        .build().map_err(|e| format!("HTTP client unavailable: {e}"))?;
    let adapter = providers::adapter(vendor);
    let url = adapter.endpoint(endpoint, model)?;
    let body = make_request(vendor, model, system, messages);
    let req = adapter.authorize(client.post(&url).json(&body), key);
    let response = req.send().map_err(|e| format!("AI request failed: {e}"))?;
    let status = response.status();
    if !status.is_success() {
        // Never reflect a vendor error body into the UI: it may contain token or prompt data.
        return Err(format!("AI provider returned HTTP {}. Check model, API key, billing and provider status.", status.as_u16()));
    }
    // Bound the read itself to avoid allocating an unbounded malicious server response.
    let mut text = String::new();
    response.take((MAX_REPLY_BYTES * 3 + 1) as u64).read_to_string(&mut text)
        .map_err(|e| format!("Could not read AI reply as UTF-8: {e}"))?;
    if text.len() > MAX_REPLY_BYTES * 3 { return Err("AI reply exceeds response size limit".into()); }
    let parsed: Value = serde_json::from_str(&text).map_err(|_| "AI response is not valid JSON".to_owned())?;
    parse_answer(vendor, &parsed)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn credentials_not_serialized() {
        let json = serde_json::to_string(&ChatFile::default()).unwrap();
        assert!(!json.contains("api_key"));
        assert!(!json.contains("password"));
        assert!(!json.contains("access_token"));
    }
    #[test] fn deny_insecure_endpoints() {
        assert!(validate_endpoint(Vendor::Custom, "http://my-vendor.test/v1/chat/completions").is_err());
        assert!(validate_endpoint(Vendor::Custom, "https://my-vendor.test/v1/chat/completions").is_ok());
        assert!(validate_endpoint(Vendor::Ollama, "http://localhost:11434/v1/chat/completions").is_ok());
    }
    #[test] fn vendor_payloads() {
        let msgs = vec![Message { role:"user".into(), content:"Hello".into() }];
        assert_eq!(make_request(Vendor::Anthropic,"model","",&msgs)["messages"][0]["role"], "user");
        assert_eq!(make_request(Vendor::Gemini,"model","",&msgs)["contents"][0]["role"], "user");
        assert_eq!(make_request(Vendor::OpenAi,"model","",&msgs)["messages"][0]["role"], "user");
    }
    #[test] fn parse_three_families() {
        assert_eq!(parse_answer(Vendor::OpenAi, &json!({"choices":[{"message":{"content":"a"}}]})).unwrap(),"a");
        assert_eq!(parse_answer(Vendor::Anthropic, &json!({"content":[{"text":"b"}]})).unwrap(),"b");
        assert_eq!(parse_answer(Vendor::Gemini, &json!({"candidates":[{"content":{"parts":[{"text":"c"}]}}]})).unwrap(),"c");
    }
    #[test]
    fn old_chat_history_without_endpoint_remains_readable() {
        let previous = r#"{"id":42,"title":"Previous chat","provider":"Custom","model":"test","messages":[{"role":"user","content":"hi"}]}"#;
        let chat: Conversation = serde_json::from_str(previous).unwrap();
        assert_eq!(chat.provider, Vendor::Custom);
        assert_eq!(chat.endpoint, None);
        assert_eq!(chat.messages.len(), 1);
    }
    #[test]
    fn local_and_remote_endpoints_are_separated() {
        assert!(validate_endpoint(Vendor::Custom, "https://host.invalid/api/chat").is_ok());
        assert!(validate_endpoint(Vendor::Custom, "http://127.0.0.1:11434/api/chat").is_err());
        assert!(validate_endpoint(Vendor::Ollama, "http://localhost:11434/api/chat").is_ok());
        assert!(validate_endpoint(Vendor::Ollama, "http://192.168.0.1:11434/api/chat").is_err());
        assert!(validate_endpoint(Vendor::Custom, "https://secret:password@host.invalid/api/chat").is_err());
    }
}
