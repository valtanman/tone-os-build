//! Optional Google account sign-in for a desktop application.
//! Uses external browser, loopback redirect, random state and PKCE. Never handles Google passwords.
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use rand::RngCore;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::io::{BufRead, BufReader, Read, Write};
use std::net::TcpListener;
use std::sync::mpsc::Sender;
use std::thread;
use std::time::{Duration, Instant};

const SERVICE: &str = "ToneEdit Studio";
const GOOGLE_TOKEN: &str = "google.oauth.tokens";

pub type GoogleLoginResult = Result<String, String>;

fn random_urlsafe() -> String {
    let mut random = [0u8; 32];
    rand::thread_rng().fill_bytes(&mut random);
    URL_SAFE_NO_PAD.encode(random)
}
fn token_entry() -> Result<keyring::Entry, String> {
    keyring::Entry::new(SERVICE, GOOGLE_TOKEN).map_err(|e| e.to_string())
}
/// Initiate local browser login. This function returns a URL to open with egui.
/// Browser window is opened only as a result of the user's explicit click.
pub fn start(client_id: &str, sender: Sender<GoogleLoginResult>) -> Result<String, String> {
    let id = client_id.trim();
    if id.is_empty() { return Err("Enter a Google Cloud *Desktop* OAuth client ID first".into()); }
    if id.chars().any(char::is_whitespace) { return Err("Google OAuth client ID is invalid".into()); }
    let listener = TcpListener::bind("127.0.0.1:0")
        .map_err(|e| format!("Could not create local OAuth callback: {e}"))?;
    listener.set_nonblocking(true).map_err(|e| e.to_string())?;
    let port = listener.local_addr().map_err(|e| e.to_string())?.port();
    let redirect = format!("http://127.0.0.1:{port}/callback");
    let state = random_urlsafe();
    let verifier = random_urlsafe();
    let digest = Sha256::digest(verifier.as_bytes());
    let challenge = URL_SAFE_NO_PAD.encode(digest);
    let mut auth = reqwest::Url::parse("https://accounts.google.com/o/oauth2/v2/auth")
        .map_err(|e| e.to_string())?;
    auth.query_pairs_mut()
        .append_pair("client_id", id)
        .append_pair("redirect_uri", &redirect)
        .append_pair("response_type", "code")
        .append_pair("scope", "openid email")
        .append_pair("access_type", "offline")
        .append_pair("code_challenge", &challenge)
        .append_pair("code_challenge_method", "S256")
        .append_pair("state", &state);
    let id = id.to_owned();
    thread::spawn(move || {
        let result = complete_login(listener, &id, &redirect, &state, &verifier);
        let _ = sender.send(result);
    });
    Ok(auth.to_string())
}

fn complete_login(listener: TcpListener, client_id: &str, redirect: &str,
                  expected_state: &str, verifier: &str) -> GoogleLoginResult {
    let deadline = Instant::now() + Duration::from_secs(180);
    let code = loop {
        if Instant::now() >= deadline { return Err("Timed out waiting for browser sign-in".into()); }
        match listener.accept() {
            Ok((mut socket, address)) => {
                if !address.ip().is_loopback() { continue; }
                socket.set_read_timeout(Some(Duration::from_secs(5))).ok();
                let mut first_line = String::new();
                {
                    // Local sockets are still untrusted. A limit on the read *itself*
                    // prevents a peer from supplying an unbounded request line.
                    let mut reader = BufReader::new((&mut socket).take(8193));
                    reader.read_line(&mut first_line).map_err(|e| format!("OAuth callback read failed: {e}"))?;
                }
                if first_line.len() > 8192 || !first_line.starts_with("GET /callback?") { continue; }
                let path = first_line.split_whitespace().nth(1).ok_or("Malformed callback")?;
                let url = reqwest::Url::parse(&format!("http://127.0.0.1{path}"))
                    .map_err(|_| "Malformed OAuth callback".to_owned())?;
                if url.path() != "/callback" { continue; }
                let pairs: std::collections::HashMap<String, String> = url.query_pairs()
                    .map(|(k,v)| (k.into_owned(), v.into_owned())).collect();
                // Reject spoofed callbacks before reporting success to the browser.
                let valid_state = pairs.get("state").map(|s| s.as_str()) == Some(expected_state);
                if !valid_state {
                    let _ = socket.write_all(b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n");
                    continue;
                }
                if let Some(error) = pairs.get("error") { return Err(format!("Google authorization rejected: {error}")); }
                let code = pairs.get("code").cloned().ok_or("Missing OAuth code")?;
                let _ = socket.write_all(b"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n<!doctype html><title>ToneEdit Studio</title><p>You may close this window and return to ToneEdit Studio.</p>");
                break code;
            }
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                thread::sleep(Duration::from_millis(150));
            }
            Err(e) => return Err(format!("OAuth callback error: {e}")),
        }
    };
    // Google's desktop-client secret is optional from an app-security standpoint;
    // where the Google Cloud OAuth configuration requires it, load it from the OS vault.
    let oauth_secret = keyring::Entry::new(SERVICE, "google.oauth.client_secret")
        .ok().and_then(|k| k.get_password().ok());
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(25))
        .redirect(reqwest::redirect::Policy::none()).build()
        .map_err(|e| e.to_string())?;
    let mut fields = vec![
        ("client_id", client_id.to_owned()),
        ("code", code),
        ("redirect_uri", redirect.to_owned()),
        ("grant_type", "authorization_code".into()),
        ("code_verifier", verifier.to_owned()),
    ];
    if let Some(secret) = oauth_secret { fields.push(("client_secret", secret)); }
    let response = client.post("https://oauth2.googleapis.com/token").form(&fields).send()
        .map_err(|e| format!("Google token request failed: {e}"))?;
    if !response.status().is_success() {
        return Err(format!("Google rejected OAuth token exchange (HTTP {})", response.status().as_u16()));
    }
    let tokens: Value = response.json().map_err(|_| "Invalid Google OAuth token response".to_owned())?;
    let access = tokens["access_token"].as_str().ok_or("Missing Google access token")?;
    let refresh = tokens["refresh_token"].as_str().unwrap_or("");
    let result = client.get("https://openidconnect.googleapis.com/v1/userinfo")
        .bearer_auth(access).send().map_err(|e| format!("Google userinfo failed: {e}"))?;
    if !result.status().is_success() { return Err("Google login succeeded but userinfo was unavailable".into()); }
    let user: Value = result.json().map_err(|_| "Google userinfo was invalid".to_owned())?;
    // Do not persist a partial login if userinfo validation failed.
    let to_save = serde_json::json!({"access_token":access,"refresh_token":refresh});
    token_entry()?.set_password(&to_save.to_string())
        .map_err(|e| format!("Could not save Google token: {e}"))?;
    Ok(user["email"].as_str().unwrap_or("account connected").to_owned())
}

pub fn save_client_secret(secret: &str) -> Result<(), String> {
    if secret.trim().is_empty() { return Err("Enter an OAuth client secret".into()); }
    keyring::Entry::new(SERVICE, "google.oauth.client_secret")
        .map_err(|e| e.to_string())?.set_password(secret.trim()).map_err(|e| e.to_string())
}

pub fn disconnect() -> Result<(), String> {
    token_entry()?.delete_credential().map_err(|e| format!("Could not remove Google token: {e}"))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn pkce_generation() {
        let one = random_urlsafe();
        assert!(one.len() >= 43);
        assert_ne!(one, random_urlsafe());
        let hash = Sha256::digest(one.as_bytes());
        assert_eq!(URL_SAFE_NO_PAD.encode(hash).len(), 43);
    }
}
