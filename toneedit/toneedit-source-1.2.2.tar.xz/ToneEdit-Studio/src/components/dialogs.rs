//! Non-blocking dialogs and confirmation components.
use crate::{Action, CloseChoice, Document, EditorApp};
use eframe::egui::{self, Color32, Key};

impl EditorApp {
    fn dialog_windows(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        if self.goto_open {
            let mut open = self.goto_open;
            let mut go = false;
            egui::Window::new("Go to line").open(&mut open).collapsible(false).resizable(false).show(ctx, |ui| {
                ui.label("Line number (starting at 1):");
                let response = ui.text_edit_singleline(&mut self.goto_input);
                if response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)) { go = true; }
                if ui.button("Go").clicked() { go = true; }
            });
            self.goto_open = open;
            if go {
                if let Ok(line) = self.goto_input.parse::<usize>() {
                    actions.push(Action::Goto(line.max(1))); self.goto_open = false;
                } else { self.show_error("Please enter a valid positive line number"); }
            }
        }
        if let Some(id) = self.pending_close {
            let title = self.docs.iter().find(|d| d.id == id).map(|d| d.title()).unwrap_or_default();
            let mut choice: Option<CloseChoice> = None;
            egui::Window::new("Unsaved changes").collapsible(false).resizable(false)
                .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0]).show(ctx, |ui| {
                ui.label(format!("Save changes to {title} before closing?"));
                ui.horizontal(|ui| {
                    if ui.button("Save").clicked() { choice = Some(CloseChoice::Save); }
                    if ui.button("Discard").clicked() { choice = Some(CloseChoice::Discard); }
                    if ui.button("Cancel").clicked() { choice = Some(CloseChoice::Cancel); }
                });
            });
            if let Some(choice) = choice {
                match choice {
                    CloseChoice::Save => {
                        if let Some(index) = self.docs.iter().position(|d| d.id == id) {
                            let former = self.active;
                            self.active = index;
                            if self.save_active(false, false) { self.pending_close = None; self.remove_doc(id); }
                            else { self.active = former.min(self.docs.len().saturating_sub(1)); }
                        } else { self.pending_close = None; }
                    }
                    CloseChoice::Discard => { self.pending_close = None; self.remove_doc(id); }
                    CloseChoice::Cancel => self.pending_close = None,
                }
            }
        }
        if let Some(message) = self.warning.clone() {
            let mut close = false;
            egui::Window::new("ToneEdit Studio — Error").collapsible(false).resizable(false)
                .anchor(egui::Align2::CENTER_CENTER, [0.0,0.0]).show(ctx, |ui| {
                ui.colored_label(Color32::LIGHT_RED, message);
                if ui.button("OK").clicked() { close = true; }
            });
            if close { self.warning = None; }
        }
        if let Some(message) = self.notice.clone() {
            let mut close = false;
            egui::Window::new("Notice").collapsible(false).resizable(false)
                .anchor(egui::Align2::CENTER_CENTER, [0.0,0.0]).show(ctx, |ui| {
                ui.label(message);
                if ui.button("OK").clicked() { close = true; }
            });
            if close { self.notice = None; }
        }
        if self.show_help {
            egui::Window::new("About ToneEdit Studio").open(&mut self.show_help)
                .default_width(500.0).show(ctx, |ui| {
                ui.heading("ToneEdit Studio 1.2.1");
                ui.label("A usable native GUI text / source editor written in Rust.");
                ui.separator();
                ui.label("Ctrl+N New · Ctrl+O Open · Ctrl+S Save · Ctrl+Shift+S Save as");
                ui.label("Ctrl+W Close tab · Ctrl+F Find/Replace · F3 Next match");
                ui.label("Ctrl+G Go to line · Ctrl+Z Undo · Ctrl+Y Redo");
                ui.label("Ctrl++ / Ctrl+- Font size. Drag files into the window to open.");
                ui.separator();
                ui.label("Session recovery: unsaved changes are saved to a local session snapshot every 15 seconds and when the app closes normally.");
                ui.label("Source files are saved with an atomic replacement and a .toneedit.bak backup.");
                ui.label("AI calls occur only on user request. API keys are kept in OS credentials, chats are local plaintext, no telemetry.");
            });
        }
        let _ = actions;
    }
}

pub(super) struct Dialogs;
impl super::WorkbenchComponent for Dialogs {
    fn id(&self) -> &'static str { "workbench.dialogs" }
    fn title(&self) -> &'static str { "Dialogs" }
    fn region(&self) -> &'static str { "Overlay" }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.dialog_windows(ctx, actions);
    }
}
