//! Centralized ToneEdit visual theme. No account, identity, or persona branding.
use eframe::egui::{self, Color32, Stroke};

pub fn apply(ctx: &egui::Context, dark: bool) {
    let mut visuals = if dark { egui::Visuals::dark() } else { egui::Visuals::light() };
    if dark {
        visuals.panel_fill = Color32::from_rgb(11, 17, 31);
        visuals.window_fill = Color32::from_rgb(17, 26, 46);
        visuals.override_text_color = Some(Color32::from_rgb(220, 233, 253));
        visuals.widgets.noninteractive.bg_fill = Color32::from_rgb(13, 23, 43);
        visuals.widgets.inactive.bg_fill = Color32::from_rgb(24, 39, 65);
        visuals.widgets.hovered.bg_fill = Color32::from_rgb(35, 66, 105);
        visuals.widgets.active.bg_fill = Color32::from_rgb(26, 93, 149);
        visuals.widgets.hovered.bg_stroke = Stroke::new(1.0, Color32::from_rgb(74, 176, 250));
        visuals.window_stroke = Stroke::new(1.0, Color32::from_rgb(53, 103, 164));
        visuals.selection.bg_fill = Color32::from_rgb(42, 105, 161);
    } else {
        visuals.panel_fill = Color32::from_rgb(242, 247, 255);
        visuals.window_fill = Color32::from_rgb(252, 254, 255);
        visuals.widgets.hovered.bg_fill = Color32::from_rgb(212, 230, 251);
        visuals.widgets.active.bg_fill = Color32::from_rgb(178, 216, 247);
        visuals.selection.bg_fill = Color32::from_rgb(146, 199, 246);
    }
    ctx.set_visuals(visuals);
}
