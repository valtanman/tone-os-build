//! ToneEdit Workbench: independent Rust GUI components mounted in a stable order.
//!
//! Each component owns its rendering entry point and its own source file. The
//! editor model is shared through explicit action commands and `EditorApp` state;
//! no component executes untrusted downloaded code or JavaScript.
mod shell;
mod explorer;
mod find;
mod editor;
mod preview;
mod status;
mod dialogs;
mod ai_chat;
pub mod theme;

use crate::{Action, EditorApp};
use eframe::egui::{self, RichText};

/// A workbench component's public integration contract. Components can be
/// mounted/reordered without changing editor file IO or the AI API adapters.
pub trait WorkbenchComponent {
    fn id(&self) -> &'static str;
    fn title(&self) -> &'static str;
    fn region(&self) -> &'static str;
    fn visible(&self, _app: &EditorApp) -> bool { true }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>);
}

static MENU_BAR: shell::MenuBar = shell::MenuBar;
static TOOLBAR: shell::Toolbar = shell::Toolbar;
static FIND_BAR: find::FindBar = find::FindBar;
static STATUS_BAR: status::StatusBar = status::StatusBar;
static TASK_CONSOLE: status::TaskConsole = status::TaskConsole;
static EXPLORER: explorer::FileExplorer = explorer::FileExplorer;
static PREVIEW: preview::MarkdownPreview = preview::MarkdownPreview;
static AI_CHAT: ai_chat::AiChat = ai_chat::AiChat;
static CENTRAL_EDITOR: editor::CentralEditor = editor::CentralEditor;
static DIALOGS: dialogs::Dialogs = dialogs::Dialogs;

/// Panels that define the workbench. `CentralEditor` is intentionally last
/// among egui panels so that it fills the remaining region.
fn registry() -> [&'static dyn WorkbenchComponent; 10] {
    [
        &MENU_BAR,
        &TOOLBAR,
        &FIND_BAR,
        &STATUS_BAR,
        &TASK_CONSOLE,
        &EXPLORER,
        &PREVIEW,
        &AI_CHAT,
        &CENTRAL_EDITOR,
        &DIALOGS,
    ]
}

pub fn draw(app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
    for component in registry() {
        if component.visible(app) {
            component.render(app, ctx, actions);
        }
    }
    component_manager(app, ctx);
}

pub fn component_manager(app: &mut EditorApp, ctx: &egui::Context) {
    if !app.components_open { return; }
    let mut open = app.components_open;
    egui::Window::new("Components / コンポーネント")
        .open(&mut open).default_width(445.0).resizable(true)
        .show(ctx, |ui| {
            ui.label(RichText::new("WORKBENCH COMPONENTS").strong());
            ui.label("各機能は独立したRustコンポーネントです。表示するパネルを選べます。");
            ui.separator();
            for component in registry() {
                ui.horizontal(|ui| {
                    ui.label(format!("{} / {}", component.title(), component.region()));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        match component.id() {
                            "workspace.explorer" => { ui.checkbox(&mut app.show_explorer, "表示"); }
                            "edit.search" => { ui.checkbox(&mut app.find.open, "表示"); }
                            "view.preview" => { ui.checkbox(&mut app.show_preview, "表示"); }
                            "dev.console" => { ui.checkbox(&mut app.show_console, "表示"); }
                            "ai.chat" => { ui.checkbox(&mut app.ai.visible, "表示"); }
                            _ => { ui.label(RichText::new("必須").small().weak()); }
                        }
                    });
                });
            }
            ui.separator();
            ui.label(RichText::new("Engine components: Files & encodings / Regex / Syntax / Cargo / AI vendors / Google OAuth / Windows installer / Uninstaller").small().weak());
            ui.label(RichText::new("This is a compile-time component system, not an untrusted binary plugin loader.").small().weak());
        });
    app.components_open = open;
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn components_have_unique_stable_ids() {
        let components = registry();
        let mut names = std::collections::HashSet::new();
        for component in components {
            assert!(!component.id().is_empty());
            assert!(names.insert(component.id()), "Duplicate component id: {}", component.id());
            assert!(!component.title().is_empty());
            assert!(!component.region().is_empty());
        }
        assert_eq!(names.len(), 10);
    }
}
