//! Markdown preview component.
use crate::EditorApp;
use eframe::egui::{self, RichText};

impl EditorApp {
    fn preview_panel(&self, ctx: &egui::Context) {
        if !self.show_preview { return; }
        egui::SidePanel::right("markdown_preview").resizable(true).default_width(390.0).show(ctx, |ui| {
            ui.strong("MARKDOWN PREVIEW");
            ui.separator();
            egui::ScrollArea::vertical().show(ui, |ui| {
                if let Some(doc) = self.active_doc() { render_markdown(ui, &doc.text); }
            });
        });
    }

}

fn render_markdown(ui: &mut egui::Ui, text: &str) {
    let mut in_code = false;
    let mut count = 0;
    for line in text.lines() {
        if count >= 3_000 { ui.label("Preview limited to first 3,000 lines"); break; }
        count += 1;
        if line.trim_start().starts_with("```") { in_code = !in_code; continue; }
        if in_code {
            ui.label(RichText::new(line).monospace().size(12.5));
        } else if let Some(stripped) = line.strip_prefix("# ") {
            ui.heading(stripped);
        } else if let Some(stripped) = line.strip_prefix("## ") {
            ui.label(RichText::new(stripped).heading().strong());
        } else if let Some(stripped) = line.strip_prefix("### ") {
            ui.label(RichText::new(stripped).strong().size(16.0));
        } else if line.starts_with("- ") || line.starts_with("* ") {
            ui.label(format!("• {}", &line[2..]));
        } else if line.trim() == "---" {
            ui.separator();
        } else if line.trim().is_empty() {
            ui.add_space(6.0);
        } else {
            ui.label(line);
        }
    }
}

pub(super) struct MarkdownPreview;
impl super::WorkbenchComponent for MarkdownPreview {
    fn id(&self) -> &'static str { "view.preview" }
    fn title(&self) -> &'static str { "Markdown preview" }
    fn region(&self) -> &'static str { "Right" }
    fn visible(&self, app: &EditorApp) -> bool { app.show_preview }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, _actions: &mut Vec<crate::Action>) {
        app.preview_panel(ctx);
    }
}
