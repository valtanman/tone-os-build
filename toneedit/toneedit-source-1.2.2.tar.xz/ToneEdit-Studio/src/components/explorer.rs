//! Folder tree / file navigation component.
use crate::{Action, EditorApp};
use eframe::egui::{self, RichText};
use std::{fs, path::{Path, PathBuf}};

impl EditorApp {
    fn workspace_panel(&self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        egui::SidePanel::left("workspace")
            .resizable(true).default_width(245.0).min_width(160.0).max_width(460.0)
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.strong("EXPLORER");
                    if ui.small_button("Open folder").clicked() { actions.push(Action::OpenFolder); }
                });
                ui.separator();
                if let Some(dir) = &self.workspace {
                    ui.label(RichText::new(dir.to_string_lossy()).small().weak());
                    egui::ScrollArea::vertical().id_salt("file_tree").show(ui, |ui| {
                        draw_directory(ui, dir, 0, actions);
                    });
                } else {
                    ui.label("No folder opened");
                    ui.label(RichText::new("Open a workspace folder to browse its files.").small().weak());
                }
            });
    }

}

fn draw_directory(ui: &mut egui::Ui, dir: &Path, depth: usize, actions: &mut Vec<Action>) {
    if depth >= 7 { ui.label(RichText::new("Maximum tree depth reached").small().weak()); return; }
    let Ok(entries) = fs::read_dir(dir) else {
        ui.label(RichText::new("No access to folder").small().weak()); return;
    };
    let mut items: Vec<PathBuf> = entries.filter_map(|e| e.ok().map(|e| e.path()))
        .filter(|p| !matches!(p.file_name().and_then(|s| s.to_str()), Some(".git" | "node_modules" | "target" | ".venv" | "__pycache__")))
        .take(300).collect();
    items.sort_by_key(|p| (!p.is_dir(), p.file_name().map(|s| s.to_ascii_lowercase())));
    for path in items {
        let name = path.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
        if path.is_dir() {
            egui::CollapsingHeader::new(format!("📁 {name}")).id_salt(&path).show(ui, |ui| {
                draw_directory(ui, &path, depth + 1, actions);
            });
        } else if ui.selectable_label(false, format!("  {name}")).clicked() {
            actions.push(Action::OpenFile(path));
        }
    }
}

pub(super) struct FileExplorer;
impl super::WorkbenchComponent for FileExplorer {
    fn id(&self) -> &'static str { "workspace.explorer" }
    fn title(&self) -> &'static str { "File explorer" }
    fn region(&self) -> &'static str { "Left" }
    fn visible(&self, app: &EditorApp) -> bool { app.show_explorer }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.workspace_panel(ctx, actions);
    }
}
