//! Search and replace toolbar component.
use crate::{Action, EditorApp};
use eframe::egui::{self, Color32, RichText};

impl EditorApp {
    fn search_panel(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        if !self.find.open { return; }
        egui::TopBottomPanel::top("findbar").show(ctx, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.label("Find:");
                if ui.add(egui::TextEdit::singleline(&mut self.find.term).desired_width(230.0)).changed() {
                    actions.push(Action::RefreshSearch);
                }
                ui.label("Replace:");
                ui.add(egui::TextEdit::singleline(&mut self.find.replace).desired_width(170.0));
                if ui.checkbox(&mut self.find.case_sensitive, "Aa").changed() { actions.push(Action::RefreshSearch); }
                if ui.checkbox(&mut self.find.regex, ".*").changed() { actions.push(Action::RefreshSearch); }
                if ui.button("Previous").clicked() { actions.push(Action::FindNext(false)); }
                if ui.button("Next F3").clicked() { actions.push(Action::FindNext(true)); }
                if ui.button("Replace").clicked() { actions.push(Action::ReplaceOne); }
                if ui.button("Replace all").clicked() { actions.push(Action::ReplaceAll); }
                if ui.button("Search folder").clicked() { actions.push(Action::SearchWorkspace); }
                if ui.button("✕").clicked() { self.find.open = false; }
            });
            ui.horizontal(|ui| {
                if !self.find.error.is_empty() {
                    ui.colored_label(Color32::LIGHT_RED, &self.find.error);
                } else {
                    let count = self.find.results.locations.len();
                    ui.label(RichText::new(format!("{} match(es){}", count,
                        if self.find.results.truncated { " (first 20,000)" } else { "" })).small().weak());
                }
            });
        });
    }

}

pub(super) struct FindBar;
impl super::WorkbenchComponent for FindBar {
    fn id(&self) -> &'static str { "edit.search" }
    fn title(&self) -> &'static str { "Find / Replace" }
    fn region(&self) -> &'static str { "Top" }
    fn visible(&self, app: &EditorApp) -> bool { app.find.open }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.search_panel(ctx, actions);
    }
}
