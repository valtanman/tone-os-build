//! Multi-vendor AI chat UI as an optional workbench component.
use crate::{Action, EditorApp};
use eframe::egui;

pub(super) struct AiChat;
impl super::WorkbenchComponent for AiChat {
    fn id(&self) -> &'static str { "ai.chat" }
    fn title(&self) -> &'static str { "AI chat / Connections" }
    fn region(&self) -> &'static str { "Right / Dialog" }
    // The settings dialogs must remain available even if the AI chat panel is hidden.
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, _actions: &mut Vec<Action>) {
        if let Some(answer) = app.ai.show(ctx) {
            // Insertion is explicitly requested by the user; AI never silently edits files.
            let cursor = app.cursor_char;
            if let Some(doc) = app.active_doc_mut() {
                let offset = doc.text.char_indices().nth(cursor).map(|(pos, _)| pos)
                    .unwrap_or(doc.text.len());
                doc.text.insert_str(offset, &answer);
                doc.dirty = true;
            }
        }
        app.ai.settings_ui(ctx);
        app.ai.confirm_delete_ui(ctx);
    }
}
