//! Document tabs and syntax-highlighted editor component.
use crate::{Action, EditorApp, syntax};
use eframe::egui::{self, Color32, RichText};

impl EditorApp {
    fn tabs(&self, ui: &mut egui::Ui, actions: &mut Vec<Action>) {
        egui::ScrollArea::horizontal().id_salt("tabs").show(ui, |ui| {
            ui.horizontal(|ui| {
                for (index, doc) in self.docs.iter().enumerate() {
                    let active = index == self.active;
                    let text = if active { RichText::new(doc.display_title()).strong() } else { RichText::new(doc.display_title()) };
                    if ui.selectable_label(active, text).clicked() { actions.push(Action::Select(index)); }
                    if ui.small_button("×").on_hover_text("Close tab").clicked() {
                        actions.push(Action::Close(doc.id));
                    }
                    ui.separator();
                }
            });
        });
    }

    fn center_panel(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        egui::CentralPanel::default().show(ctx, |ui| {
            self.tabs(ui, actions);
            ui.separator();
            let Some(doc) = self.docs.get_mut(self.active) else { return; };
            let lang = syntax::Language::from_path(doc.path.as_deref());
            let dark = self.dark;
            let font_size = self.font_size;
            let id = egui::Id::new(("toneedit-text", doc.id));
            let mut layouter = move |ui: &egui::Ui, buf: &dyn egui::TextBuffer, wrap_width: f32| {
                let layout = syntax::highlight(buf.as_str(), lang, dark, wrap_width, font_size);
                ui.fonts_mut(|fonts| fonts.layout_job(layout))
            };
            let line_total = doc.text.bytes().filter(|b| *b == b'\n').count() + 1;
            let gutter = if line_total <= 4_000 {
                let digits = line_total.to_string().len();
                Some((1..=line_total).map(|line| format!("{line:>digits$}"))
                    .collect::<Vec<_>>().join("\n"))
            } else { None };
            let output = egui::ScrollArea::both().id_salt(("editor-scroll", doc.id)).show(ui, |ui| {
                ui.horizontal_top(|ui| {
                    if let Some(gutter) = &gutter {
                        ui.label(RichText::new(gutter).monospace().size(font_size)
                            .color(if dark { Color32::GRAY } else { Color32::DARK_GRAY }));
                        ui.separator();
                    }
                    egui::TextEdit::multiline(&mut doc.text)
                        .id(id)
                        .font(egui::TextStyle::Monospace)
                        .code_editor()
                        .desired_width(f32::INFINITY)
                        .desired_rows(35)
                        .lock_focus(true)
                        .layouter(&mut layouter)
                        .show(ui)
                }).inner
            });
            let output = output.inner;
            if output.response.changed() {
                doc.dirty = true;
                actions.push(Action::RefreshSearch);
            }
            if let Some(range) = output.cursor_range {
                self.cursor_char = range.primary.index;
            }
            if let Some((start,end)) = self.jump.take() {
                if let Some(mut state) = egui::TextEdit::load_state(ctx, id) {
                    use egui::text::{CCursor, CCursorRange};
                    state.cursor.set_char_range(Some(CCursorRange::two(CCursor::new(start), CCursor::new(end))));
                    state.store(ctx, id);
                    ctx.memory_mut(|m| m.request_focus(id));
                }
            }
        });
    }

}

pub(super) struct CentralEditor;
impl super::WorkbenchComponent for CentralEditor {
    fn id(&self) -> &'static str { "edit.document" }
    fn title(&self) -> &'static str { "Code editor / Tabs" }
    fn region(&self) -> &'static str { "Center" }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.center_panel(ctx, actions);
    }
}
