//! Background task output and status bar components.
use crate::{Action, EditorApp, document::{Encoding, LineEnding}, search, syntax};
use eframe::egui::{self, Color32, RichText};

impl EditorApp {
    fn console_panel(&self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        if !self.show_console { return; }
        egui::TopBottomPanel::bottom("cargo_console").resizable(true).default_height(175.0).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.strong("CARGO / TASK OUTPUT");
                if self.task_running { ui.spinner(); ui.label("running"); }
            });
            ui.separator();
            egui::ScrollArea::vertical().stick_to_bottom(true).show(ui, |ui| {
                ui.label(RichText::new(&self.console).monospace().size(12.0));
                if !self.workspace_search_summary.is_empty() {
                    ui.separator();
                    ui.label(RichText::new(&self.workspace_search_summary).strong());
                    for hit in &self.workspace_hits {
                        let row = format!("{}:{}  {}", hit.path.display(), hit.line, hit.excerpt);
                        if ui.selectable_label(false, row).clicked() {
                            actions.push(Action::OpenAt(hit.path.clone(), hit.line));
                        }
                    }
                }
            });
        });
    }

    fn status_bar(&mut self, ctx: &egui::Context) {
        egui::TopBottomPanel::bottom("status").show(ctx, |ui| {
            ui.horizontal(|ui| {
                if let Some(doc) = self.docs.get_mut(self.active) {
                    let (line, col) = search::line_col_at_char(&doc.text, self.cursor_char);
                    ui.label(format!("Ln {}, Col {}  |  {} lines  |  {} chars", line, col,
                        doc.text.bytes().filter(|b| *b == b'\n').count() + 1, doc.text.chars().count()));
                    ui.separator();
                    ui.label(syntax::Language::from_path(doc.path.as_deref()).label());
                    ui.separator();
                    let before_enc = doc.encoding;
                    egui::ComboBox::from_id_salt(("encoding", doc.id))
                        .selected_text(doc.encoding.label())
                        .show_ui(ui, |ui| {
                            for enc in Encoding::ALL {
                                ui.selectable_value(&mut doc.encoding, enc, enc.label());
                            }
                        });
                    if before_enc != doc.encoding { doc.dirty = true; }
                    let before_eol = doc.newline;
                    egui::ComboBox::from_id_salt(("line-ending", doc.id))
                        .selected_text(doc.newline.label())
                        .show_ui(ui, |ui| {
                            for eol in LineEnding::ALL {
                                ui.selectable_value(&mut doc.newline, eol, eol.label());
                            }
                        });
                    if before_eol != doc.newline { doc.dirty = true; }
                    if doc.dirty { ui.colored_label(Color32::YELLOW, "Modified"); }
                    if doc.mixed_endings { ui.colored_label(Color32::YELLOW, "Mixed original EOL"); }
                }
                ui.separator();
                ui.label(RichText::new(&self.status).small().weak());
            });
        });
    }

}

pub(super) struct StatusBar;
impl super::WorkbenchComponent for StatusBar {
    fn id(&self) -> &'static str { "workbench.status" }
    fn title(&self) -> &'static str { "Status bar" }
    fn region(&self) -> &'static str { "Bottom" }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, _actions: &mut Vec<Action>) {
        app.status_bar(ctx);
    }
}
pub(super) struct TaskConsole;
impl super::WorkbenchComponent for TaskConsole {
    fn id(&self) -> &'static str { "dev.console" }
    fn title(&self) -> &'static str { "Cargo / Task console" }
    fn region(&self) -> &'static str { "Bottom" }
    fn visible(&self, app: &EditorApp) -> bool { app.show_console }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.console_panel(ctx, actions);
    }
}
