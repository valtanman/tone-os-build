//! Menu and toolbar components.
use crate::{Action, CargoAction, EditorApp};
use eframe::egui::{self, Color32, RichText};

impl EditorApp {
    fn menu_bar(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        egui::TopBottomPanel::top("menu").show(ctx, |ui| {
            egui::menu::bar(ui, |ui| {
                ui.label(RichText::new("◆ ToneEdit Studio").strong().color(Color32::from_rgb(100, 194, 222)));
                ui.separator();
                ui.menu_button("File", |ui| {
                    menu_item(ui, "New                 Ctrl+N", Action::New, actions);
                    menu_item(ui, "Open...             Ctrl+O", Action::OpenDialog, actions);
                    menu_item(ui, "Open folder...", Action::OpenFolder, actions);
                    ui.separator();
                    menu_item(ui, "Save                Ctrl+S", Action::Save, actions);
                    menu_item(ui, "Save as...     Ctrl+Shift+S", Action::SaveAs, actions);
                    menu_item(ui, "Save all", Action::SaveAll, actions);
                    if ui.button("Close tab             Ctrl+W").clicked() {
                        if let Some(doc) = self.active_doc() { actions.push(Action::Close(doc.id)); }
                        ui.close_menu();
                    }
                    ui.separator();
                    menu_item(ui, "Reload from disk", Action::ReloadFile, actions);
                    ui.menu_button("Advanced", |ui| {
                        if ui.button("Overwrite changed file (with .bak)").clicked() {
                            actions.push(Action::SaveForce); ui.close_menu();
                        }
                    });
                    if !self.recent.is_empty() {
                        ui.separator();
                        ui.menu_button("Recent files", |ui| {
                            for path in self.recent.iter() {
                                if ui.button(path.to_string_lossy()).clicked() {
                                    actions.push(Action::OpenFile(path.clone())); ui.close_menu();
                                }
                            }
                        });
                    }
                });
                ui.menu_button("Edit", |ui| {
                    ui.label("Undo  Ctrl+Z  /  Redo  Ctrl+Y");
                    ui.label("Cut  Ctrl+X  /  Copy  Ctrl+C  /  Paste  Ctrl+V");
                    ui.separator();
                    menu_item(ui, "Find / Replace      Ctrl+F", Action::ToggleFind, actions);
                    menu_item(ui, "Go to line          Ctrl+G", Action::ToggleGoto, actions);
                    ui.separator();
                    menu_item(ui, "Trim trailing whitespace", Action::TrimTrailingWhitespace, actions);
                    menu_item(ui, "Sort all lines", Action::SortLines, actions);
                });
                ui.menu_button("Tools", |ui| {
                    menu_item(ui, "Format JSON", Action::JsonPretty, actions);
                    menu_item(ui, "Minify JSON", Action::JsonCompact, actions);
                    ui.separator();
                    for task in [CargoAction::Check, CargoAction::Test, CargoAction::Build, CargoAction::Format] {
                        menu_item(ui, task.label(), Action::Cargo(task), actions);
                    }
                });
                ui.menu_button("View", |ui| {
                    menu_item(ui, "Toggle light/dark theme", Action::ToggleTheme, actions);
                    menu_item(ui, "Increase font size", Action::FontSize(1.0), actions);
                    menu_item(ui, "Decrease font size", Action::FontSize(-1.0), actions);
                    menu_item(ui, "Toggle file explorer", Action::ToggleExplorer, actions);
                    menu_item(ui, "Toggle Markdown preview", Action::TogglePreview, actions);
                    if ui.button("Toggle task output").clicked() { self.show_console = !self.show_console; ui.close_menu(); }
                    ui.separator();
                    menu_item(ui, "Components / コンポーネント...", Action::ComponentsSettings, actions);
                });
                ui.menu_button("AI", |ui| {
                    menu_item(ui, "AI chat / multi-vendor", Action::ToggleAi, actions);
                    menu_item(ui, "Connections / API keys / Google", Action::AiSettings, actions);
                });
                ui.menu_button("Help", |ui| { menu_item(ui, "About / shortcuts", Action::ShowHelp, actions); });
            });
        });
    }

    fn toolbar(&mut self, ctx: &egui::Context, actions: &mut Vec<Action>) {
        egui::TopBottomPanel::top("toolbar").show(ctx, |ui| {
            ui.horizontal(|ui| {
                if ui.button("＋ New").clicked() { actions.push(Action::New); }
                if ui.button("📂 Open").clicked() { actions.push(Action::OpenDialog); }
                if ui.button("💾 Save").clicked() { actions.push(Action::Save); }
                if ui.button("Save all").clicked() { actions.push(Action::SaveAll); }
                ui.separator();
                if ui.button("⌕ Find").clicked() { actions.push(Action::ToggleFind); }
                if ui.button("JSON").clicked() { actions.push(Action::JsonPretty); }
                if ui.button("Cargo check").clicked() { actions.push(Action::Cargo(CargoAction::Check)); }
                ui.separator();
                if ui.button("Markdown preview").clicked() { actions.push(Action::TogglePreview); }
                if ui.button("✦ AI Chat").clicked() { actions.push(Action::ToggleAi); }
                if let Some(doc) = self.active_doc() {
                    ui.label(RichText::new(doc.path.as_ref().map(|p| p.to_string_lossy().to_string())
                        .unwrap_or_else(|| "Unsaved document".into())).small().weak());
                }
            });
        });
    }

}

fn menu_item(ui: &mut egui::Ui, label: &str, action: Action, actions: &mut Vec<Action>) {
    if ui.button(label).clicked() { actions.push(action); ui.close_menu(); }
}

pub(super) struct MenuBar;
impl super::WorkbenchComponent for MenuBar {
    fn id(&self) -> &'static str { "workbench.menu" }
    fn title(&self) -> &'static str { "Menu bar" }
    fn region(&self) -> &'static str { "Top" }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.menu_bar(ctx, actions);
    }
}
pub(super) struct Toolbar;
impl super::WorkbenchComponent for Toolbar {
    fn id(&self) -> &'static str { "workbench.toolbar" }
    fn title(&self) -> &'static str { "Toolbar" }
    fn region(&self) -> &'static str { "Top" }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>) {
        app.toolbar(ctx, actions);
    }
}
