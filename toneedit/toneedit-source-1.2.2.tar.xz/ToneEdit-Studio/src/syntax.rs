//! Fast, dependency-free lexical colorization. This is a highlighter, not a parser.
use eframe::egui::{self, text::LayoutJob, Color32, FontId, TextFormat};
use std::path::Path;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Language { Rust, Python, Js, Html, Css, Json, Toml, Shell, Sql, CLike, Markdown, Plain }
impl Language {
    pub fn from_path(path: Option<&Path>) -> Self {
        let Some(path) = path else { return Self::Plain; };
        let ext = path.extension().and_then(|s| s.to_str()).unwrap_or("").to_lowercase();
        match ext.as_str() {
            "rs" => Self::Rust,
            "py" => Self::Python,
            "js" | "ts" | "jsx" | "tsx" => Self::Js,
            "html" | "htm" | "xml" | "svg" => Self::Html,
            "css" | "scss" => Self::Css,
            "json" | "jsonl" => Self::Json,
            "toml" | "ini" | "cfg" => Self::Toml,
            "sh" | "bash" | "ps1" | "bat" | "cmd" | "zsh" => Self::Shell,
            "sql" => Self::Sql,
            "c" | "h" | "cpp" | "hpp" | "cc" | "cs" | "java" | "go" | "mq4" | "mq5" => Self::CLike,
            "md" | "markdown" | "rst" => Self::Markdown,
            _ => Self::Plain,
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            Self::Rust => "Rust", Self::Python => "Python", Self::Js => "JS/TS",
            Self::Html => "HTML/XML", Self::Css => "CSS", Self::Json => "JSON",
            Self::Toml => "TOML/INI", Self::Shell => "Script", Self::Sql => "SQL",
            Self::CLike => "C-like", Self::Markdown => "Markdown", Self::Plain => "Plain text",
        }
    }
}

pub fn highlight(text: &str, lang: Language, dark: bool, wrap_width: f32, font_size: f32) -> LayoutJob {
    let mut job = LayoutJob::default();
    job.wrap.max_width = wrap_width;
    let plain = if dark { Color32::from_rgb(220, 228, 239) } else { Color32::from_rgb(32, 39, 50) };
    let comment = if dark { Color32::from_rgb(114, 151, 121) } else { Color32::from_rgb(72, 123, 78) };
    let string = if dark { Color32::from_rgb(228, 167, 113) } else { Color32::from_rgb(159, 71, 30) };
    let keyword = if dark { Color32::from_rgb(153, 170, 255) } else { Color32::from_rgb(75, 79, 180) };
    let number = if dark { Color32::from_rgb(175, 199, 123) } else { Color32::from_rgb(96, 119, 22) };
    let directive = if dark { Color32::from_rgb(113, 195, 211) } else { Color32::from_rgb(22, 118, 142) };
    let fmt = |color| TextFormat { font_id: FontId::monospace(font_size), color, ..Default::default() };
    if lang == Language::Plain || text.len() > 2_000_000 {
        job.append(text, 0.0, fmt(plain));
        return job;
    }
    let bytes = text.as_bytes();
    let mut i = 0;
    let mut from = 0;
    let mut quote: Option<u8> = None;
    let mut in_block_comment = false;
    let has_slash_comments = matches!(lang, Language::Rust | Language::Js | Language::CLike | Language::Css);
    let has_hash_comments = matches!(lang, Language::Python | Language::Shell | Language::Toml);
    let has_dash_comments = lang == Language::Sql;
    let has_c_comments = has_slash_comments || lang == Language::Sql;
    while i < bytes.len() {
        if in_block_comment {
            if text[i..].starts_with("*/") {
                i += 2;
                job.append(&text[from..i], 0.0, fmt(comment));
                from = i; in_block_comment = false;
            } else { i += text[i..].chars().next().unwrap().len_utf8(); }
            continue;
        }
        if let Some(q) = quote {
            if bytes[i] == b'\\' && i + 1 < bytes.len() {
                i += 1 + text[i + 1..].chars().next().unwrap().len_utf8();
            } else if bytes[i] == q {
                i += 1;
                job.append(&text[from..i], 0.0, fmt(string));
                from = i; quote = None;
            } else {
                i += text[i..].chars().next().unwrap().len_utf8();
            }
            continue;
        }
        let line_comment = (has_slash_comments && text[i..].starts_with("//"))
            || (has_hash_comments && bytes[i] == b'#')
            || (has_dash_comments && text[i..].starts_with("--"))
            || (lang == Language::Html && text[i..].starts_with("<!--"));
        if line_comment {
            if from < i { job.append(&text[from..i], 0.0, fmt(plain)); }
            let end = if lang == Language::Html && text[i..].starts_with("<!--") {
                text[i..].find("-->").map(|n| i + n + 3).unwrap_or(text.len())
            } else { text[i..].find('\n').map(|n| i + n).unwrap_or(text.len()) };
            job.append(&text[i..end], 0.0, fmt(comment));
            i = end; from = i;
            continue;
        }
        if has_c_comments && text[i..].starts_with("/*") {
            if from < i { job.append(&text[from..i], 0.0, fmt(plain)); }
            in_block_comment = true; from = i; i += 2;
            continue;
        }
        if bytes[i] == b'"' || (bytes[i] == b'\'' && !matches!(lang, Language::Json | Language::Markdown | Language::Rust)) {
            if from < i { job.append(&text[from..i], 0.0, fmt(plain)); }
            quote = Some(bytes[i]); from = i; i += 1; continue;
        }
        let ch = text[i..].chars().next().unwrap();
        if ch.is_ascii_digit() && (i == 0 || !bytes[i - 1].is_ascii_alphanumeric()) {
            if from < i { job.append(&text[from..i], 0.0, fmt(plain)); }
            let start = i; i += 1;
            while i < bytes.len() && (bytes[i].is_ascii_alphanumeric() || bytes[i] == b'.' || bytes[i] == b'_') { i += 1; }
            job.append(&text[start..i], 0.0, fmt(number)); from = i; continue;
        }
        if ch.is_ascii_alphabetic() || ch == '_' {
            let start = i; i += 1;
            while i < bytes.len() && (bytes[i].is_ascii_alphanumeric() || bytes[i] == b'_') { i += 1; }
            let word = &text[start..i];
            let color = if is_keyword(word, lang) { Some(keyword) }
                else if matches!(word, "true" | "false" | "null" | "None" | "True" | "False") { Some(number) }
                else if word.starts_with("TODO") || word.starts_with("FIXME") { Some(directive) }
                else { None };
            if let Some(color) = color {
                if from < start { job.append(&text[from..start], 0.0, fmt(plain)); }
                job.append(word, 0.0, fmt(color)); from = i;
            }
            continue;
        }
        if lang == Language::Markdown && (i == 0 || bytes[i - 1] == b'\n') && (ch == '#' || ch == '>') {
            if from < i { job.append(&text[from..i], 0.0, fmt(plain)); }
            let end = text[i..].find('\n').map(|n| i + n).unwrap_or(text.len());
            job.append(&text[i..end], 0.0, fmt(keyword)); i = end; from = i; continue;
        }
        i += ch.len_utf8();
    }
    if from < text.len() {
        let col = if in_block_comment { comment } else if quote.is_some() { string } else { plain };
        job.append(&text[from..], 0.0, fmt(col));
    }
    job
}

fn is_keyword(word: &str, lang: Language) -> bool {
    let keywords = match lang {
        Language::Rust => "fn let mut pub use mod impl struct enum trait where self Self async await move match if else for while loop break continue return const static type unsafe crate super in as ref dyn Some None Ok Err",
        Language::Python => "def class import from as for while if elif else try except finally raise return yield lambda with async await pass global nonlocal is not in and or del",
        Language::Js => "function const let var class extends export default import from async await return throw try catch finally if else for while switch case new typeof instanceof this interface type public private",
        Language::CLike => "int char long short float double void bool class struct enum namespace using public private protected static const virtual override return if else while for do switch case break continue new delete auto typedef template typename include",
        Language::Sql => "SELECT FROM WHERE JOIN LEFT RIGHT INNER OUTER INSERT INTO UPDATE DELETE CREATE TABLE ALTER DROP GROUP BY ORDER HAVING LIMIT AS DISTINCT NULL NOT AND OR BEGIN COMMIT",
        Language::Json => "true false null",
        Language::Shell => "if then else fi for do done while function return case esac echo set export foreach switch param begin end",
        Language::Toml => "true false",
        Language::Css => "color background font display flex grid position padding margin border width height",
        Language::Html => "html head body div span script style section article main header footer table",
        Language::Markdown | Language::Plain => "",
    };
    keywords.split_whitespace().any(|k| k == word)
        || (lang == Language::Sql && keywords.split_whitespace().any(|k| k.eq_ignore_ascii_case(word)))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn language_extensions() {
        assert_eq!(Language::from_path(Some(Path::new("a.rs"))), Language::Rust);
        assert_eq!(Language::from_path(Some(Path::new("test.MQ5"))), Language::CLike);
    }
    #[test] fn unicode_highlight_no_panic() {
        let job = highlight("fn main() { println!(\"日本語 🌸\"); }", Language::Rust, true, 1000.0, 14.0);
        assert!(!job.sections.is_empty());
    }
}
