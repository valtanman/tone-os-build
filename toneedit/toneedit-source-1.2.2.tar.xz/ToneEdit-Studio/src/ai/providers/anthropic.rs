//! Anthropic Messages API adapter component.
use super::{AiProviderAdapter, Message};
use reqwest::blocking::RequestBuilder;
use serde_json::{json, Value};

pub struct Anthropic;
impl AiProviderAdapter for Anthropic {
    fn format_request(&self, model: &str, system: &str, messages: &[Message]) -> Value {
        let turns: Vec<Value> = messages.iter()
            .filter(|m| m.role == "user" || m.role == "assistant")
            .map(|m| json!({"role":m.role,"content":m.content})).collect();
        let mut body = json!({"model":model,"max_tokens":2048,"messages":turns});
        if !system.is_empty() { body["system"] = json!(system); }
        body
    }
    fn extract_text(&self, response: &Value) -> Option<String> {
        response["content"].as_array().map(|parts| {
            parts.iter().filter_map(|p| p["text"].as_str()).collect::<Vec<_>>().join("\n")
        })
    }
    fn authorize(&self, request: RequestBuilder, key: &str) -> RequestBuilder {
        request.header("x-api-key", key).header("anthropic-version", "2023-06-01")
    }
}
