//! Google Gemini generateContent API adapter component.
use super::{AiProviderAdapter, Message};
use reqwest::blocking::RequestBuilder;
use serde_json::{json, Value};

pub struct Gemini;
impl AiProviderAdapter for Gemini {
    fn format_request(&self, _model: &str, system: &str, messages: &[Message]) -> Value {
        let turns: Vec<Value> = messages.iter()
            .filter(|m| m.role == "user" || m.role == "assistant")
            .map(|m| json!({"role":if m.role == "assistant" { "model" } else { "user" },
                              "parts":[{"text":m.content}]})).collect();
        let mut body = json!({"contents":turns});
        if !system.is_empty() {
            body["systemInstruction"] = json!({"parts":[{"text":system}]});
        }
        body
    }
    fn extract_text(&self, response: &Value) -> Option<String> {
        response["candidates"].as_array().and_then(|c| c.first())
            .and_then(|c| c["content"]["parts"].as_array())
            .map(|parts| parts.iter().filter_map(|p| p["text"].as_str()).collect::<Vec<_>>().join("\n"))
    }
    fn endpoint(&self, endpoint: &str, model: &str) -> Result<String, String> {
        if !model.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.')) {
            return Err("Gemini model ID contains invalid characters".to_owned());
        }
        Ok(format!("{}/models/{}:generateContent", endpoint.trim_end_matches('/'), model))
    }
    fn authorize(&self, request: RequestBuilder, key: &str) -> RequestBuilder {
        request.header("x-goog-api-key", key)
    }
}
