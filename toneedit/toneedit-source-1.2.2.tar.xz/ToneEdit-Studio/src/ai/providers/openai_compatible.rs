//! OpenAI Chat Completions family and OpenAI-compatible hosted / local services.
use super::{AiProviderAdapter, Message};
use reqwest::blocking::RequestBuilder;
use serde_json::{json, Value};

pub struct OpenAiCompatible;
impl AiProviderAdapter for OpenAiCompatible {
    fn format_request(&self, model: &str, system: &str, messages: &[Message]) -> Value {
        let mut content = vec![];
        if !system.is_empty() { content.push(json!({"role":"system","content":system})); }
        for msg in messages {
            content.push(json!({"role":msg.role,"content":msg.content}));
        }
        json!({"model":model,"messages":content,"stream":false})
    }
    fn extract_text(&self, response: &Value) -> Option<String> {
        response["choices"].as_array().and_then(|choices| choices.first())
            .and_then(|choice| choice["message"]["content"].as_str())
            .map(str::to_owned)
    }
    fn authorize(&self, request: RequestBuilder, key: &str) -> RequestBuilder {
        if key.is_empty() { request } else { request.bearer_auth(key) }
    }
}
