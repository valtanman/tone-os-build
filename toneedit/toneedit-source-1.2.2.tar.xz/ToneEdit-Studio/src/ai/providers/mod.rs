//! Vendor adapter components. Each API family implements the same Rust trait.
//! Adding a new family does not require changing the conversation UI.
mod openai_compatible;
mod anthropic;
mod gemini;

use super::{Message, Vendor};
use reqwest::blocking::RequestBuilder;
use serde_json::Value;

/// Object-safe component interface for outgoing API requests and text replies.
pub trait AiProviderAdapter: Send + Sync {
    fn format_request(&self, model: &str, system: &str, messages: &[Message]) -> Value;
    fn extract_text(&self, response: &Value) -> Option<String>;
    fn endpoint(&self, endpoint: &str, _model: &str) -> Result<String, String> {
        Ok(endpoint.to_owned())
    }
    fn authorize(&self, request: RequestBuilder, api_key: &str) -> RequestBuilder;
}

static OPENAI: openai_compatible::OpenAiCompatible = openai_compatible::OpenAiCompatible;
static ANTHROPIC: anthropic::Anthropic = anthropic::Anthropic;
static GEMINI: gemini::Gemini = gemini::Gemini;

pub fn adapter(vendor: Vendor) -> &'static dyn AiProviderAdapter {
    match vendor {
        Vendor::Anthropic => &ANTHROPIC,
        Vendor::Gemini => &GEMINI,
        _ => &OPENAI,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn adapter_families_return_expected_payloads() {
        let msgs = vec![Message { role:"user".to_owned(), content:"Hello".to_owned() }];
        assert_eq!(adapter(Vendor::OpenAi).format_request("model","",&msgs)["messages"][0]["role"], "user");
        assert_eq!(adapter(Vendor::Anthropic).format_request("model","",&msgs)["messages"][0]["role"], "user");
        assert_eq!(adapter(Vendor::Gemini).format_request("model","",&msgs)["contents"][0]["role"], "user");
    }
}
