//! Build the Windows editor, uninstaller and one-file setup in the correct order.
//! This release tool, like ToneEdit Studio, is written in Rust. No Python/Node runtime.
use std::fs;
use std::fs::File;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

const VERSION: &str = "1.2.1";
const EDITOR: &str = "toneedit-studio.exe";
const UNINSTALL: &str = "toneedit-uninstall.exe";
const SETUP: &str = "toneedit-setup.exe";

fn main() {
    if let Err(error) = run() {
        eprintln!("\nBUILD FAILED: {error}");
        std::process::exit(1);
    }
}

fn cargo(root: &Path, args: &[&str]) -> Result<(), String> {
    println!("\n> cargo {}", args.join(" "));
    let status = Command::new("cargo").current_dir(root).args(args)
        .status().map_err(|e| format!("Could not start cargo: {e}"))?;
    if !status.success() {
        return Err(format!("cargo {} exited with {status}", args.join(" ")));
    }
    Ok(())
}

fn run() -> Result<(), String> {
    if !cfg!(windows) {
        return Err("This release command builds native Windows .exe files. Run it on Windows 10/11 x64 or the supplied GitHub Actions Windows runner.".into());
    }
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let root = root.canonicalize().map_err(|e| e.to_string())?;
    // Binary payloads must exist before the setup crate is compiled: include_bytes!
    // embeds their exact bytes into the single-file Rust installer.
    cargo(&root, &["test", "--manifest-path", "Cargo.toml"])?;
    cargo(&root, &["build", "--release", "--bin", "toneedit-studio"])?;
    cargo(&root, &["test", "--manifest-path", "packaging/uninstall/Cargo.toml", "--target-dir", "target"])?;
    cargo(&root, &["build", "--release", "--manifest-path", "packaging/uninstall/Cargo.toml", "--target-dir", "target"])?;
    cargo(&root, &["test", "--manifest-path", "packaging/setup/Cargo.toml", "--target-dir", "target"])?;
    cargo(&root, &["build", "--release", "--manifest-path", "packaging/setup/Cargo.toml", "--target-dir", "target"])?;

    let release_dir = root.join("target/release");
    for binary in [EDITOR, UNINSTALL, SETUP] {
        let executable = release_dir.join(binary);
        println!("\n> {} --self-test", executable.display());
        let status = Command::new(&executable).arg("--self-test").status()
            .map_err(|e| format!("Could not run smoke test for {binary}: {e}"))?;
        if !status.success() {
            return Err(format!("Executable smoke test failed for {binary}: {status}"));
        }
    }
    let bundle_name = format!("ToneEdit-Studio-{VERSION}-Windows-x64-MIT-Free");
    let dist = root.join("dist").join(&bundle_name);
    fs::create_dir_all(&dist).map_err(|e| format!("Could not make output directory: {e}"))?;
    let files: [(&str, PathBuf); 10] = [
        (SETUP, release_dir.join(SETUP)),
        (EDITOR, release_dir.join(EDITOR)),
        (UNINSTALL, release_dir.join(UNINSTALL)),
        ("ToneEdit.ico", root.join("assets/ToneEdit.ico")),
        ("ToneEdit-Setup.ico", root.join("assets/ToneEdit-Setup.ico")),
        ("ToneEdit-Uninstall.ico", root.join("assets/ToneEdit-Uninstall.ico")),
        ("README.md", root.join("README.md")),
        ("COMPONENTS.md", root.join("COMPONENTS.md")),
        ("QA_REPORT.md", root.join("QA_REPORT.md")),
        ("LICENSE", root.join("LICENSE")),
    ];
    for (name, from) in &files {
        let bytes = fs::copy(from, dist.join(name))
            .map_err(|e| format!("Failed to collect {}: {e}", from.display()))?;
        if bytes == 0 {
            return Err(format!("Output file is unexpectedly empty: {}", from.display()));
        }
        println!("Collected: {name} ({bytes} bytes)");
    }
    let archive = root.join("dist").join(format!("{bundle_name}.zip"));
    write_zip(&archive, &dist, &files.map(|(name, _)| name))
        .map_err(|e| format!("ZIP creation failed: {e}"))?;
    println!("\nSUCCESS: {}", archive.display());
    println!("Install: {}", dist.join(SETUP).display());
    println!("All three EXEs, documentation, MIT license and icons are in the release folder.");
    println!("IMPORTANT: Test installation, AI connections and uninstallation on a Windows PC before public release.");
    Ok(())
}

fn write_u16(out: &mut File, number: u16) -> io::Result<()> { out.write_all(&number.to_le_bytes()) }
fn write_u32(out: &mut File, number: u32) -> io::Result<()> { out.write_all(&number.to_le_bytes()) }
fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = !0u32;
    for byte in bytes {
        crc ^= u32::from(*byte);
        for _ in 0..8 { crc = (crc >> 1) ^ (if crc & 1 != 0 { 0xEDB8_8320 } else { 0 }); }
    }
    !crc
}

/// Build a standard ZIP archive using the ZIP "stored" method, without invoking
/// any external executable or adding a non-Rust dependency.
fn write_zip(path: &Path, directory: &Path, names: &[&str]) -> io::Result<()> {
    use std::io::Seek;
    let mut out = File::create(path)?;
    struct Entry { name: String, crc: u32, size: u32, offset: u32 }
    let mut entries = Vec::new();
    for name in names {
        let file = fs::read(directory.join(name))?;
        let name_bytes = name.as_bytes();
        let len = u32::try_from(file.len()).map_err(|_| io::Error::other("ZIP member >4 GiB"))?;
        let pos = u32::try_from(out.stream_position()?).map_err(|_| io::Error::other("ZIP >4 GiB"))?;
        let name_len = u16::try_from(name_bytes.len()).map_err(|_| io::Error::other("ZIP name too long"))?;
        let crc = crc32(&file);
        write_u32(&mut out, 0x0403_4b50)?;
        write_u16(&mut out, 20)?;  // version required
        write_u16(&mut out, 0x0800)?; // UTF-8 filenames
        write_u16(&mut out, 0)?;  // no compression
        write_u16(&mut out, 0)?;  // mod time
        write_u16(&mut out, 0)?;  // mod date
        write_u32(&mut out, crc)?;
        write_u32(&mut out, len)?;
        write_u32(&mut out, len)?;
        write_u16(&mut out, name_len)?;
        write_u16(&mut out, 0)?;
        out.write_all(name_bytes)?;
        out.write_all(&file)?;
        entries.push(Entry { name: name.to_string(), crc, size: len, offset: pos });
    }
    let central_start = u32::try_from(out.stream_position()?).map_err(|_| io::Error::other("ZIP >4 GiB"))?;
    for entry in &entries {
        write_u32(&mut out, 0x0201_4b50)?;
        write_u16(&mut out, 20)?; // creator version
        write_u16(&mut out, 20)?; // required version
        write_u16(&mut out, 0x0800)?;
        write_u16(&mut out, 0)?;
        write_u16(&mut out, 0)?;
        write_u16(&mut out, 0)?;
        write_u32(&mut out, entry.crc)?;
        write_u32(&mut out, entry.size)?;
        write_u32(&mut out, entry.size)?;
        write_u16(&mut out, u16::try_from(entry.name.len()).map_err(|_| io::Error::other("Name too long"))?)?;
        write_u16(&mut out, 0)?;
        write_u16(&mut out, 0)?;
        write_u16(&mut out, 0)?;
        write_u16(&mut out, 0)?;
        write_u32(&mut out, 0)?;
        write_u32(&mut out, entry.offset)?;
        out.write_all(entry.name.as_bytes())?;
    }
    let central_end = u32::try_from(out.stream_position()?).map_err(|_| io::Error::other("ZIP >4 GiB"))?;
    let count = u16::try_from(entries.len()).map_err(|_| io::Error::other("Too many ZIP members"))?;
    write_u32(&mut out, 0x0605_4b50)?;
    write_u16(&mut out, 0)?;
    write_u16(&mut out, 0)?;
    write_u16(&mut out, count)?;
    write_u16(&mut out, count)?;
    write_u32(&mut out, central_end - central_start)?;
    write_u32(&mut out, central_start)?;
    write_u16(&mut out, 0)?;
    out.flush()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn known_crc32() {
        assert_eq!(crc32(b"123456789"), 0xcbf4_3926);
        assert_eq!(crc32(b""), 0);
    }
}
