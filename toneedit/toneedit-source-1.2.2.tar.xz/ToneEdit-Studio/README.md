# ToneEdit Studio 1.2.1 — MIT / FREE / Rust-only Windows editor and installer

> **QA / 重要:** v1.2.1は保存競合、AI送信先の分離、OAuth、インストール先の安全性を強化したソース改訂版です。ビルド後の3種類のEXEには `--self-test` を追加しています。**この作業環境でWindows EXEのコンパイル、GUI実機操作、インストール・アンインストールの実行は完了していません。** 出荷判定は `QA_REPORT.md` を参照してください。

**ToneEdit Studio is an independent, generic desktop application.** It has no connection to other product brands and contains **no hard-coded personal identity, private profile, user persona or account credentials**. All application source code, network communication, graphical user interface, setup program and uninstall program are written in **Rust**. No Python, Node.js, Electron, JavaScript app runtime, external command-line installer or admin privilege is required to **run** the installed application.

**Official distribution policy:** ToneEdit Studio itself is 100% free, without advertisements, licenses to activate, trial restrictions, account-gated features or paid tiers. The application and its own source code, installer, uninstaller and generated icon artwork are released under the **MIT License** (see `LICENSE`). Anyone may use, inspect, modify and redistribute MIT-covered code. Third-party API services may charge separately; this application does not collect such fees. MIT also permits third parties to sell copies or derivatives, so no one can guarantee every unofficial derivative will be free. Bundled third-party dependencies retain their own licenses.

> **Release honesty:** This source package includes the full Rust source for the editor, AI connectors, setup program and uninstaller, Windows ICO files and an automated Windows build pipeline. In the originating environment, there is no `cargo` / `rustc` or Windows runtime. Consequently, **no Windows binary was compiled and no Windows installer was executed or tested here**. The installer source includes both executable payloads only when built according to the workflow below. This is not a claim that the `.exe` files in the workflow have already been generated.

## What the Windows release produces

| Artifact | Purpose |
|---|---|
| `toneedit-setup.exe` | **Single-file Windows installer**, with editor EXE, uninstaller EXE, three ICO files, README and LICENSE embedded at build time |
| `toneedit-studio.exe` | Standalone Rust graphical editor and AI chat application |
| `toneedit-uninstall.exe` | Native Rust GUI uninstaller, installed by setup |
| `ToneEdit.ico` | Editor icon, containing sizes 256, 128, 64, 48, 32, 16 |
| `ToneEdit-Setup.ico` | Installer icon, same size variants |
| `ToneEdit-Uninstall.ico` | Uninstaller icon, same size variants |

The setup program installs per-user by default to `%LOCALAPPDATA%\Programs\ToneEdit Studio`, registers an entry in Windows **Installed apps** and Start Menu shortcuts, and optionally adds a desktop shortcut. It doesn't access vendor accounts during installation. It also bundles `COMPONENTS.md`, describing the modular architecture.

The uninstaller removes only known program filenames and shortcuts, refuses to delete unknown directories, and **does not delete user source documents**. An opt-in checkbox can additionally erase local app settings, AI chat history and stored credentials. If unchecked, settings and credentials are retained for reinstallation. A temporary uninstaller copy may remain in the Windows Temp directory until restart/cleanup.

## Build and package everything in one command (Windows x64)

Install the stable **Rust MSVC toolchain**, Visual Studio C++ Build Tools and Windows SDK, then open a terminal at the repository root:

```powershell
cargo run --release --manifest-path tools/build-all/Cargo.toml --target-dir tools/build-all/target
```

The pure-Rust build orchestrator runs tests, builds **the editor, uninstaller, and setup EXEs in the required order**, then creates both `dist/ToneEdit-Studio-1.2.1-Windows-x64-MIT-Free/` and `dist/ToneEdit-Studio-1.2.1-Windows-x64-MIT-Free.zip`. The setup executable itself embeds the other executables, three icons, README and the MIT license. The build program uses only the Rust standard library and does not call Python, JavaScript, a PowerShell packaging script or external ZIP programs.

**This command cannot produce a Windows EXE on Linux without a Windows-compatible toolchain and suitable cross-build support.** It must be actually run on Windows or GitHub Actions Windows runners.

## Building all executable artifacts on Windows

**Prerequisites:** Windows 10/11 x64, [Rust stable](https://rustup.rs/) with MSVC toolchain, Visual Studio Build Tools (C++ toolchain and Windows SDK), internet access for Cargo dependencies. Build only after reviewing source code and verifying dependencies.

Open PowerShell in the repository root and execute these steps **in order**:

```powershell
cargo test
cargo build --release --bin toneedit-studio
cargo build --release --manifest-path packaging/uninstall/Cargo.toml --target-dir target
cargo build --release --manifest-path packaging/setup/Cargo.toml --target-dir target
```

The installer embeds `target\release\toneedit-studio.exe` and `target\release\toneedit-uninstall.exe` at **compile time**. That is why the **setup program must be built last**. If you modify the editor or uninstaller, rebuild the setup last so its embedded payloads are updated. To install, run:

```powershell
.\target\release\toneedit-setup.exe
```

To test the portable editor without installation:

```powershell
.\target\release\toneedit-studio.exe
```

Alternatively, upload the sources to your own GitHub repository and run **Actions → ToneEdit Studio - Rust Windows app and single-EXE installer → Run workflow**. The workflow builds all 3 EXEs and uploads them as a downloadable CI artifact. No credentials are needed for the build; each API user configures their own accounts after installing.

## Core editor features

### Component-style workbench

All workbench panes are separate Rust components registered by stable IDs in `src/components/mod.rs`. **View → Components / コンポーネント** provides switches for the explorer, find/replace, Markdown preview, Cargo/task console, and AI chat. Each component has a `WorkbenchComponent` interface for its title, ID, region, visibility and rendering. Core editor, encoding, search, vendor APIs, Google OAuth, installer and uninstaller are separate engine packages/modules. See [COMPONENTS.md](COMPONENTS.md) for the module map, extension procedure and limitations. No third-party binary plugin loader is implied.

- Multiple file tabs, drag and drop, local workspace folder explorer, recently opened files.
- Open/save/save all/Save As, dirty state, file backups, external-change checks.
- UTF-8, UTF-8 BOM, UTF-16 LE/BE BOM and Shift-JIS encoding; LF/CRLF/CR detection and conversion.
- Regular-expression search/replace, case sensitivity, workspace-wide search, go to line.
- Rust, C/C++, C#, MQL4/5, Python **source syntax** (Python **runtime not used**), JavaScript, TypeScript, HTML, CSS, SQL, JSON, Shell and Markdown highlighting.
- JSON formatting and minification, Markdown side preview, line sorting, trailing whitespace cleanup.
- Cargo check/test/build/format commands; recovery snapshots every ~15 seconds.
- Dark/light mode; default Japanese font fallback when available.

### Current editor limitations

The editor uses a standard egui text widget with a 32 MiB editable file limit, simple syntax highlighting, and no LSP, DAP, dedicated CSV spreadsheet or HEX editor. It is not a complete replacement for every feature of commercial IDEs or office suites.

## Multi-AI connections (AI menu)

Open **AI → AI chat / multi-vendor**, then **AI → Connections / API keys / Google**.

| Provider | Adapter | API key location | Suggested editable model |
|---|---|---|---|
| OpenAI | Chat Completions-compatible | OS credential vault | `gpt-4.1-mini` |
| Anthropic Claude | Messages API | OS credential vault | `claude-sonnet-4-5` |
| Google Gemini | `generateContent` API | OS credential vault | `gemini-2.5-flash` |
| xAI Grok | OpenAI-compatible | OS credential vault | `grok-3-mini` |
| DeepSeek | OpenAI-compatible | OS credential vault | `deepseek-chat` |
| Mistral | OpenAI-compatible | OS credential vault | `mistral-small-latest` |
| Groq | OpenAI-compatible | OS credential vault | `llama-3.3-70b-versatile` |
| OpenRouter | OpenAI-compatible | OS credential vault | `openai/gpt-4.1-mini` |
| Together AI | OpenAI-compatible | OS credential vault | `meta-llama/Llama-3.3-70B-Instruct-Turbo` |
| Perplexity | OpenAI-compatible | OS credential vault | `sonar` |
| Ollama | Local OpenAI-compatible | Not required | `llama3.2` |
| Custom provider | HTTPS OpenAI-compatible | OS credential vault | User-defined |

The model strings are **editable examples**: availability, pricing, account eligibility and service compatibility are determined by each provider and can change. You need a **vendor-issued API key** for each cloud provider you want to use. A web chat subscription is not generally interchangeable with API entitlement or billing.

The application provides a **text-oriented common interface**, rather than pretending the different companies' private ChatGPT/Claude/Gemini web-app sessions are interchangeable. Features such as voice, image generation, all native file upload formats, proprietary agent/tool runtimes, vendor-specific plugins and paid web-account chat history are **not cloned or synced**. API calls return non-streaming text responses in this version.

### AI chat controls

- Switch provider and model from a graphical combo box / input field.
- Create, select and delete separate conversation threads.
- Write text prompts, attach local **text files up to 24 KiB** to a **draft**, review the draft and explicitly click **Send**.
- Copy an AI answer or **Insert answer into editor** via an explicit button (no silent edits).
- Export a conversation as Markdown.
- Optional custom system instructions are **empty by default**, with no embedded persona or personal data.
- Network requests are made only after you press **Send**, with connect and total timeouts, HTTPS for cloud services and no automatic URL redirects for requests carrying credentials.

**Security and data retention:** API keys are stored via the `keyring` Rust crate using the operating system's credential facilities; they are never written to `ai_chat.json`. The chat history, prompt contents, selected model and optional custom instructions are stored **as plaintext** under `%APPDATA%\ToneEditStudio\ai_chat.json` for continuity. Protect your Windows account and avoid sharing this file if conversations contain confidential data. The editor's recovery snapshots are also stored locally in plaintext. The selected AI provider receives the messages you explicitly send, subject to the provider's own privacy terms and charges. There is no application telemetry. A user-specified custom HTTPS server can receive your API key and prompts, so enter only a trusted endpoint. Do not enter vendor account passwords into API-key fields.

### Google account connection

Under Connections, supply a **Google Cloud OAuth Client ID configured as a Desktop application** (plus its **OAuth client secret** if your Google OAuth configuration requires one). Click **Sign in with Google**.

1. ToneEdit Studio starts a TCP listener bound only to `127.0.0.1` on a random port.
2. Your system browser opens the official Google authorization page using OAuth 2.0 authorization code flow with a cryptographically random state value and **PKCE SHA-256** challenge.
3. You sign in **only on Google's website**, grant the minimum `openid email` scopes, and return to the desktop application.
4. The received access/refresh tokens are saved to the OS credential vault, not the chat JSON file.
5. Disconnect removes the saved Google token (it does not revoke the token remotely).

**Google OAuth sign-in is separate from the Gemini API key**. Signing into Google does not authorize the app to access Gmail/Drive or grant Gemini API billing. Google token refresh and other Google service permissions are not yet implemented. The optional Google account email is displayed after a successful sign-in but is not persisted to the app's local profile.

### Privacy constraints

- No built-in individual, personality profile or hard-coded person names.
- No account passwords collected by the editor.
- No vendor web-account session impersonation or third-party password scraping.
- No embedded API keys, tokens, OAuth client IDs or phone/email addresses.
- No automatic model calls or hidden file uploads.

## Source tree

```text
ToneEdit-Studio/
  Cargo.toml, build.rs, LICENSE, README.md
  src/
    main.rs          Graphical editor and menu
    document.rs      Encoding, line endings and safe file saving
    search.rs        Unicode-aware search and replacement
    syntax.rs        Source syntax highlighting
    workspace.rs     Folder-wide search
    ai.rs            Vendor adapters, secure credential UI, AI chat history
    ai/providers/    Independent OpenAI-compatible, Anthropic, Gemini API adapters
    google_oauth.rs  Desktop browser OAuth 2.0 + PKCE
    components/      Workbench component registry and independent UI modules
  packaging/
    setup/           Rust native setup wizard; bundles all executable payloads
    uninstall/       Rust native uninstall wizard and credentials cleanup
  assets/
    ToneEdit*.ico    Windows icons (256/128/64/48/32/16px)
    ToneEdit*.png    Source visual assets
    ToneEdit*.svg    Vector source assets
  tools/build-all/  Dependency-free Rust one-command build and ZIP packager
  examples/          Sample Rust/Markdown/JSON documents
  .github/workflows/windows-build.yml
  COMPONENTS.md      Component contract, extension instructions
```

## Automated and manual verification

The code contains Rust unit tests for encoding round trips, backups, search, JSON chat payloads, response parsing, endpoint restrictions, PKCE and protection against serializing credentials. GitHub Actions is configured to run tests on Windows and build all three EXEs. **Neither CI nor real provider sign-ins or API calls have been run in this chat session.** You should validate setup, repair/reinstall, uninstall, API communication, and Google OAuth with testing credentials on a Windows test machine before distributing publicly.

No code signing certificate is included. Unsigned Windows executables may trigger SmartScreen or antivirus warnings until signed and reputation is established.

## License and pricing

**MIT License; official releases are permanently free of charge.** No trial expiration, license key, activation, paid edition, ads or telemetry. The MIT notice in `LICENSE` must be retained when redistributing MIT-covered sources or substantial portions. Third-party AI model services and API billing are independent. Other parties may charge for their own redistribution or modified versions, because MIT explicitly allows commercial use.

The standalone Windows installer includes a copy of `LICENSE` and installs it alongside `README.md`; uninstall removes those program copies without deleting user-authored documents.
