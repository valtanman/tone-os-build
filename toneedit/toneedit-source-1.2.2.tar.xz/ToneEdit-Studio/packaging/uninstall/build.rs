fn main() {
    #[cfg(windows)]
    {
        let mut res = winres::WindowsResource::new();
        res.set_icon("../../assets/ToneEdit-Uninstall.ico");
        res.set("ProductName", "ToneEdit Studio");
        res.set("FileDescription", "ToneEdit Studio — Uninstaller");
        res.compile().expect("Could not embed Windows uninstaller icon");
    }
}
