#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]
//! ToneEdit Studio Rust uninstaller; preserves user documents and chat data unless opted out.
use eframe::egui::{self, Color32, RichText};
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};
use std::thread;
use winreg::enums::HKEY_CURRENT_USER;
use winreg::RegKey;

const KEY: &str = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\ToneEditStudio";
const PRODUCT_MARKER: &str = "ToneEdit Studio 1.2.1";

fn main() -> eframe::Result<()> {
    if std::env::args().any(|arg| arg == "--self-test") {
        if PRODUCT_MARKER.trim().is_empty() || !KEY.ends_with("ToneEditStudio") {
            std::process::exit(1);
        }
        return Ok(());
    }
    // The installed uninstaller makes a temporary copy before removing its own directory.
    if !std::env::args().any(|a| a == "--worker") {
        if let Err(err) = launch_from_temp() {
            eprintln!("Could not start ToneEdit uninstaller: {err}");
        } else { return Ok(()); }
    }
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_title("ToneEdit Studio | Uninstall")
            .with_inner_size([650., 360.]),
        ..Default::default()
    };
    eframe::run_native("ToneEdit Studio — Uninstall", options, Box::new(|cc| {
        cc.egui_ctx.set_visuals(egui::Visuals::dark());
        Ok(Box::<Uninstaller>::default())
    }))
}
fn launch_from_temp() -> Result<(), String> {
    let exe = std::env::current_exe().map_err(|e| e.to_string())?;
    let unique = format!("toneedit-uninstaller-{}-{}.exe", std::process::id(),
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default().as_secs());
    let temp = std::env::temp_dir().join(unique);
    fs::copy(exe, &temp).map_err(|e| format!("Cannot create temporary uninstaller copy: {e}"))?;
    std::process::Command::new(temp).arg("--worker").spawn()
        .map_err(|e| format!("Cannot run uninstaller: {e}"))?;
    Ok(())
}

#[derive(Default)]
struct Uninstaller {
    remove_settings: bool,
    started: bool,
    result_rx: Option<Receiver<Result<String, String>>>,
    finished: bool,
    message: String,
}

fn uninstall(remove_settings: bool) -> Result<String, String> {
    let registry = RegKey::predef(HKEY_CURRENT_USER);
    let key = registry.open_subkey(KEY).map_err(|e| format!("Installation record not found: {e}"))?;
    let location: String = key.get_value("InstallLocation")
        .map_err(|e| format!("Install path not recorded: {e}"))?;
    let folder = PathBuf::from(&location);
    if !folder.is_absolute() || folder.components().count() < 3 {
        return Err("Unsafe installation path; refusing to remove files".into());
    }
    let metadata = fs::symlink_metadata(&folder)
        .map_err(|e| format!("Cannot inspect installation directory: {e}"))?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err("Installation folder must be a real directory; refusing to follow links".into());
    }
    let marker = folder.join("toneedit-install.marker");
    let content = fs::read_to_string(&marker)
        .map_err(|_| "ToneEdit product marker missing; refusing to delete unknown folder".to_owned())?;
    if content.trim() != PRODUCT_MARKER && content.trim() != "ToneEdit Studio 1.2.0" {
        return Err("Product marker did not match; uninstall was aborted".into());
    }
    // Remove only known filenames. Never recursively erase a user-selected folder.
    for name in ["toneedit-studio.exe", "toneedit-uninstall.exe", "ToneEdit.ico",
        "ToneEdit-Setup.ico", "ToneEdit-Uninstall.ico", "README.md", "COMPONENTS.md", "QA_REPORT.md", "LICENSE", "toneedit-install.marker"] {
        let path = folder.join(name);
        if path.is_file() { fs::remove_file(&path).map_err(|e| format!("Cannot remove {}: {e}. Close ToneEdit Studio and retry.",path.display()))?; }
    }
    // Leave any unknown files in the directory untouched.
    let _ = fs::remove_dir(&folder);
    if let Some(appdata) = std::env::var_os("APPDATA") {
        let start = PathBuf::from(&appdata)
            .join(r"Microsoft\Windows\Start Menu\Programs\ToneEdit Studio");
        for file in ["ToneEdit Studio.lnk", "Uninstall ToneEdit Studio.lnk"] {
            let _ = fs::remove_file(start.join(file));
        }
        let _ = fs::remove_dir(&start);
        if remove_settings {
            let data = PathBuf::from(appdata).join("ToneEditStudio");
            if data.is_dir() { fs::remove_dir_all(&data)
                .map_err(|e| format!("Program removed; settings removal failed: {e}"))?; }
        }
    }
    if let Some(profile) = std::env::var_os("USERPROFILE") {
        let desktop = PathBuf::from(profile).join("Desktop").join("ToneEdit Studio.lnk");
        let _ = fs::remove_file(desktop);
    }
    if remove_settings { remove_secrets(); }
    registry.delete_subkey(KEY).map_err(|e| format!("Program files removed, but registry cleanup failed: {e}"))?;
    schedule_temp_cleanup();
    Ok(if remove_settings {
        "ToneEdit Studio, application settings and stored API credentials were removed. External documents were preserved.".into()
    } else {
        "ToneEdit Studio application files were removed. Chat history, settings and API keys were preserved for reinstall. External documents were not touched.".into()
    })
}
fn remove_secrets() {
    for vendor in ["openai", "anthropic", "gemini", "xai", "deepseek", "mistral", "groq",
        "openrouter", "together", "perplexity", "ollama", "custom"] {
        if let Ok(entry) = keyring::Entry::new("ToneEdit Studio", &format!("provider.{vendor}.api_key")) {
            let _ = entry.delete_credential();
        }
    }
    for name in ["google.oauth.tokens", "google.oauth.client_secret"] {
        if let Ok(entry) = keyring::Entry::new("ToneEdit Studio", name) {
            let _ = entry.delete_credential();
        }
    }
}
fn schedule_temp_cleanup() {
    // Windows cannot delete an executing EXE immediately. Try to delete temporary copy on reboot.
    #[cfg(windows)] {
        use std::os::windows::ffi::OsStrExt;
        #[link(name="kernel32")]
        extern "system" { fn MoveFileExW(from: *const u16, to: *const u16, flags: u32) -> i32; }
        if let Ok(path) = std::env::current_exe() {
            if path.starts_with(std::env::temp_dir()) {
                let wide: Vec<_> = path.as_os_str().encode_wide().chain(Some(0)).collect();
                let _ = unsafe { MoveFileExW(wide.as_ptr(), std::ptr::null(), 0x4) };
            }
        }
    }
}

impl eframe::App for Uninstaller {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(rx) = &self.result_rx {
            if let Ok(outcome) = rx.try_recv() {
                self.finished = true;
                self.message = match outcome { Ok(msg) => msg, Err(e) => format!("Uninstall error: {e}") };
                self.result_rx = None;
            }
        }
        egui::CentralPanel::default().frame(egui::Frame::default()
            .fill(Color32::from_rgb(11, 17, 32)).inner_margin(egui::Margin::same(22)))
            .show(ctx, |ui| {
            ui.heading(RichText::new("ToneEdit Studio — UNINSTALL")
                .color(Color32::from_rgb(118, 180, 252)));
            ui.separator();
            if !self.started {
                ui.label("Do you want to remove ToneEdit Studio from this computer?");
                ui.label("Installed app and Start Menu entries will be removed.");
                ui.add_space(13.);
                ui.checkbox(&mut self.remove_settings,
                    "Also delete local settings, chat history, Google tokens and stored AI API keys");
                ui.label(RichText::new("Default: preserve your settings and chat history for possible reinstallation. Never deletes source documents.")
                    .small().weak());
                ui.add_space(20.);
                if ui.button("Uninstall ToneEdit Studio").clicked() {
                    self.started = true;
                    let remove_settings = self.remove_settings;
                    let (tx,rx) = mpsc::channel();
                    self.result_rx = Some(rx);
                    thread::spawn(move || { let _ = tx.send(uninstall(remove_settings)); });
                }
                if ui.button("Cancel").clicked() { ctx.send_viewport_cmd(egui::ViewportCommand::Close); }
            } else if !self.finished {
                ui.spinner();
                ui.label("Removing installed files and registration...");
            } else {
                ui.label(&self.message);
                if ui.button("Close").clicked() { ctx.send_viewport_cmd(egui::ViewportCommand::Close); }
            }
        });
        ctx.request_repaint_after(std::time::Duration::from_millis(250));
    }
}
