#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]
//! ToneEdit Studio self-contained Rust Windows installer.
//! The release workflow builds editor and uninstaller first, then embeds both executables.
use eframe::egui::{self, Color32, RichText};
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};
use std::thread;
use winreg::enums::HKEY_CURRENT_USER;
use winreg::RegKey;

const APP_EXE: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/release/toneedit-studio.exe"));
const UNINSTALL_EXE: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/release/toneedit-uninstall.exe"));
const APP_ICON: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../assets/ToneEdit.ico"));
const SETUP_ICON: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../assets/ToneEdit-Setup.ico"));
const UNINSTALL_ICON: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../assets/ToneEdit-Uninstall.ico"));
const README: &str = include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../README.md"));
const LICENSE: &str = include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../LICENSE"));
const COMPONENTS: &str = include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../COMPONENTS.md"));
const QA_REPORT: &str = include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../QA_REPORT.md"));
const UNINSTALL_KEY: &str = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\ToneEditStudio";
const PRODUCT_MARKER: &str = "ToneEdit Studio 1.2.1";

#[derive(Clone, Copy, PartialEq, Eq)]
enum Page { Welcome, Options, Installing, Complete }

struct Setup {
    page: Page,
    install_to: String,
    desktop: bool,
    run_after: bool,
    error: Option<String>,
    log: String,
    result_rx: Option<Receiver<Result<String, String>>>,
    icon: egui::TextureHandle,
}

fn main() -> eframe::Result<()> {
    if std::env::args().any(|arg| arg == "--self-test") {
        if !APP_EXE.starts_with(b"MZ") || !UNINSTALL_EXE.starts_with(b"MZ") {
            eprintln!("Embedded executable is not a Windows PE file");
            std::process::exit(1);
        }
        if !APP_ICON.starts_with(&[0, 0, 1, 0]) || !LICENSE.starts_with("MIT License") {
            eprintln!("Bundled icon or MIT license is invalid");
            std::process::exit(1);
        }
        if image::load_from_memory(include_bytes!("../../../assets/ToneEdit-Setup.png")).is_err() {
            eprintln!("Embedded installer artwork is invalid");
            std::process::exit(1);
        }
        return Ok(());
    }
    let decoded = image::load_from_memory(include_bytes!("../../../assets/ToneEdit-Setup.png"))
        .expect("Embedded installer artwork is invalid").to_rgba8();
    let icon = egui::IconData { width: decoded.width(), height: decoded.height(), rgba: decoded.into_raw() };
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_title("ToneEdit Studio | Installer")
            .with_inner_size([820.0, 560.0]).with_min_inner_size([740.0, 500.0])
            .with_icon(icon),
        ..Default::default()
    };
    eframe::run_native("ToneEdit Studio — Setup", options, Box::new(|cc| {
        cc.egui_ctx.set_visuals(egui::Visuals::dark());
        let img = image::load_from_memory(include_bytes!("../../../assets/ToneEdit-Setup.png"))
            .expect("Embedded installer artwork").to_rgba8();
        let color = egui::ColorImage::from_rgba_unmultiplied(
            [img.width() as usize, img.height() as usize], img.as_raw());
        let icon = cc.egui_ctx.load_texture("installer-icon", color, egui::TextureOptions::LINEAR);
        Ok(Box::new(Setup { page: Page::Welcome, install_to: default_directory().to_string_lossy().into(),
            desktop: true, run_after: false, error: None, log: String::new(), result_rx: None, icon }))
    }))
}
fn default_directory() -> PathBuf {
    std::env::var_os("LOCALAPPDATA").map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir).join("Programs").join("ToneEdit Studio")
}
fn start_menu_dir() -> Result<PathBuf, String> {
    Ok(PathBuf::from(std::env::var_os("APPDATA").ok_or("APPDATA not set")?)
        .join(r"Microsoft\Windows\Start Menu\Programs\ToneEdit Studio"))
}
fn desktop_link() -> Option<PathBuf> {
    std::env::var_os("USERPROFILE")
        .map(PathBuf::from).map(|p| p.join("Desktop").join("ToneEdit Studio.lnk"))
}

fn checked_install_path(raw: &str) -> Result<PathBuf, String> {
    let path = PathBuf::from(raw.trim());
    if !path.is_absolute() { return Err("Choose an absolute installation path".into()); }
    if path.components().any(|c| matches!(c, std::path::Component::ParentDir)) {
        return Err("Parent directory segments are not allowed in the install path".into());
    }
    if path.parent().is_none() || path.components().count() < 3 {
        return Err("Refusing to install to the drive root or an unsafe directory".into());
    }
    Ok(path)
}
/// The installer must not overwrite a README, EXE or license belonging to
/// another program just because a user selected an occupied folder.
fn validate_install_destination(root: &Path) -> Result<(), String> {
    if !root.exists() { return Ok(()); }
    let metadata = fs::symlink_metadata(root).map_err(|e| e.to_string())?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err("Installation destination must be a real directory, not a link or file".into());
    }
    let mut entries = fs::read_dir(root).map_err(|e| e.to_string())?;
    if entries.next().is_none() { return Ok(()); }
    let marker = fs::read_to_string(root.join("toneedit-install.marker"))
        .map_err(|_| "This folder already contains other files; choose an empty folder or a previous ToneEdit installation".to_owned())?;
    if marker.trim() != PRODUCT_MARKER && marker.trim() != "ToneEdit Studio 1.2.0" {
        return Err("The target folder is not an installation of this ToneEdit version; choose an empty folder".into());
    }
    Ok(())
}
#[cfg(windows)]
fn atomic_replace(from: &Path, to: &Path) -> std::io::Result<()> {
    use std::os::windows::ffi::OsStrExt;
    #[link(name="kernel32")]
    extern "system" { fn MoveFileExW(from: *const u16, to: *const u16, flags: u32) -> i32; }
    let a: Vec<_> = from.as_os_str().encode_wide().chain(Some(0)).collect();
    let b: Vec<_> = to.as_os_str().encode_wide().chain(Some(0)).collect();
    if unsafe { MoveFileExW(a.as_ptr(), b.as_ptr(), 0x1 | 0x8) } == 0 {
        Err(std::io::Error::last_os_error())
    } else { Ok(()) }
}
fn write_asset(path: &Path, content: &[u8]) -> Result<(), String> {
    let name = path.file_name().ok_or("Invalid asset path")?.to_string_lossy();
    let temp = path.with_file_name(format!("{name}.toneedit-pending"));
    fs::write(&temp, content).map_err(|e| format!("Cannot stage {}: {e}", path.display()))?;
    #[cfg(windows)]
    let result = atomic_replace(&temp, path);
    #[cfg(not(windows))]
    let result = fs::rename(&temp, path);
    result.map_err(|e| format!("Cannot install {}: {e} (close the running app first)", path.display()))
}
fn shortcut(target: &Path, link: &Path) -> Result<(), String> {
    let t = target.to_str().ok_or("Non-Unicode application path")?;
    let l = link.to_str().ok_or("Non-Unicode shortcut path")?;
    let sl = mslnk::ShellLink::new(t).map_err(|e| format!("Shortcut initialization failed: {e}"))?;
    sl.create_lnk(l).map_err(|e| format!("Shortcut writing failed: {e}"))
}
fn install(root: PathBuf, desktop: bool) -> Result<String, String> {
    validate_install_destination(&root)?;
    fs::create_dir_all(&root).map_err(|e| format!("Cannot create destination: {e}"))?;
    let app = root.join("toneedit-studio.exe");
    let uninstaller = root.join("toneedit-uninstall.exe");
    // All program payloads are inside this single installer EXE.
    for (name, content) in [
        ("toneedit-studio.exe", APP_EXE),
        ("toneedit-uninstall.exe", UNINSTALL_EXE),
        ("ToneEdit.ico", APP_ICON),
        ("ToneEdit-Setup.ico", SETUP_ICON),
        ("ToneEdit-Uninstall.ico", UNINSTALL_ICON),
        ("README.md", README.as_bytes()),
        ("COMPONENTS.md", COMPONENTS.as_bytes()),
        ("QA_REPORT.md", QA_REPORT.as_bytes()),
        ("LICENSE", LICENSE.as_bytes()),
    ] { write_asset(&root.join(name), content)?; }
    // Mark an installation as owned only after all payload files were written.
    write_asset(&root.join("toneedit-install.marker"), format!("{PRODUCT_MARKER}\n").as_bytes())?;
    let menu = start_menu_dir()?;
    fs::create_dir_all(&menu).map_err(|e| format!("Could not create Start Menu entries: {e}"))?;
    shortcut(&app, &menu.join("ToneEdit Studio.lnk"))?;
    shortcut(&uninstaller, &menu.join("Uninstall ToneEdit Studio.lnk"))?;
    if desktop {
        if let Some(link) = desktop_link() {
            shortcut(&app, &link)?;
        }
    }
    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    let (uninstall, _) = hkcu.create_subkey(UNINSTALL_KEY)
        .map_err(|e| format!("Could not register application: {e}"))?;
    let install_str = root.to_string_lossy().into_owned();
    uninstall.set_value("DisplayName", &"ToneEdit Studio").map_err(|e| e.to_string())?;
    uninstall.set_value("DisplayVersion", &"1.2.1").map_err(|e| e.to_string())?;
    uninstall.set_value("Publisher", &"ToneEdit Studio contributors").map_err(|e| e.to_string())?;
    uninstall.set_value("InstallLocation", &install_str).map_err(|e| e.to_string())?;
    uninstall.set_value("DisplayIcon", &app.to_string_lossy().into_owned()).map_err(|e| e.to_string())?;
    uninstall.set_value("UninstallString", &format!("\"{}\"", uninstaller.display()))
        .map_err(|e| e.to_string())?;
    uninstall.set_value("NoModify", &1_u32).map_err(|e| e.to_string())?;
    uninstall.set_value("NoRepair", &1_u32).map_err(|e| e.to_string())?;
    Ok(format!("Installation completed. Files installed to {}", root.display()))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_populated_foreign_directory_and_accepts_owned_one() {
        let folder = std::env::temp_dir().join(format!("toneedit-install-test-{}", std::process::id()));
        let _ = fs::remove_dir_all(&folder);
        fs::create_dir(&folder).unwrap();
        assert!(validate_install_destination(&folder).is_ok());
        fs::write(folder.join("README.md"), "Do not overwrite this file").unwrap();
        assert!(validate_install_destination(&folder).is_err());
        fs::write(folder.join("toneedit-install.marker"), format!("{PRODUCT_MARKER}\n")).unwrap();
        assert!(validate_install_destination(&folder).is_ok());
        fs::remove_dir_all(folder).unwrap();
    }
}

impl eframe::App for Setup {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(rx) = &self.result_rx {
            if let Ok(result) = rx.try_recv() {
                match result {
                    Ok(message) => { self.log = message; self.page = Page::Complete; }
                    Err(err) => { self.error = Some(err); self.page = Page::Options; }
                }
                self.result_rx = None;
            }
        }
        egui::CentralPanel::default().frame(egui::Frame::default()
            .fill(Color32::from_rgb(10, 14, 31)).inner_margin(egui::Margin::same(22)))
            .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.image((self.icon.id(), egui::vec2(112., 112.)));
                ui.vertical(|ui| {
                    ui.add_space(12.);
                    ui.label(RichText::new("ToneEdit Studio").size(36.).strong()
                        .color(Color32::from_rgb(90, 205, 255)));
                    ui.label(RichText::new("ULTIMATE  ·  RUST NATIVE  ·  MULTI-AI")
                        .size(15.).strong().color(Color32::from_rgb(177, 150, 250)));
                    ui.label("Standalone editor + multi-vendor AI chat + secure connections");
                });
            });
            ui.add_space(14.);
            ui.separator();
            ui.add_space(12.);
            match self.page {
                Page::Welcome => {
                    ui.heading("Welcome / インストールへようこそ");
                    ui.add_space(9.);
                    ui.label("This wizard installs ToneEdit Studio, including its integrated AI chat and uninstaller.");
                    ui.label("The installer embeds all program executables, icons and documentation.");
                    ui.label("Your Google/vendor passwords are NOT required for installation.");
                    ui.label(RichText::new("100% FREE / 完全無料 ・ MIT open source ・ No ads / No license activation").color(Color32::from_rgb(121, 228, 195)));
                    ui.add_space(14.);
                    ui.label(RichText::new("No administrator privileges required · Windows 10 / 11 · No telemetry")
                        .color(Color32::from_rgb(121, 228, 195)));
                    if ui.button("Continue →").clicked() { self.page = Page::Options; }
                }
                Page::Options => {
                    ui.heading("Installation options / インストール設定");
                    ui.label("Installation directory:");
                    ui.add(egui::TextEdit::singleline(&mut self.install_to).desired_width(f32::INFINITY));
                    ui.checkbox(&mut self.desktop, "Create desktop shortcut");
                    ui.checkbox(&mut self.run_after, "Launch ToneEdit Studio after setup");
                    ui.add_space(10.);
                    if ui.button("Install ToneEdit Studio").clicked() {
                        match checked_install_path(&self.install_to) {
                            Ok(root) => {
                                self.error = None; self.page = Page::Installing;
                                let (tx,rx) = mpsc::channel();
                                self.result_rx = Some(rx);
                                let desktop = self.desktop;
                                thread::spawn(move || { let _ = tx.send(install(root,desktop)); });
                            }
                            Err(e) => self.error = Some(e),
                        }
                    }
                }
                Page::Installing => {
                    ui.heading("Installing / ファイルを展開中");
                    ui.spinner();
                    ui.label("Writing application binaries, creating shortcuts and registering uninstall information...");
                }
                Page::Complete => {
                    ui.heading("Installation successful / インストール完了");
                    ui.label(RichText::new("✓ ToneEdit Studio is ready").size(22.)
                        .color(Color32::from_rgb(106, 226, 171)));
                    ui.label(&self.log);
                    ui.add_space(9.);
                    if ui.button("Launch ToneEdit Studio").clicked() {
                        let app = PathBuf::from(&self.install_to).join("toneedit-studio.exe");
                        match std::process::Command::new(&app).spawn() {
                            Ok(_) => ctx.send_viewport_cmd(egui::ViewportCommand::Close),
                            Err(e) => self.error = Some(format!("Could not launch: {e}")),
                        }
                    }
                    if self.run_after {
                        self.run_after = false;
                        let app = PathBuf::from(&self.install_to).join("toneedit-studio.exe");
                        if let Err(e) = std::process::Command::new(&app).spawn() {
                            self.error = Some(format!("Could not launch: {e}"));
                        }
                    }
                    if ui.button("Finish").clicked() { ctx.send_viewport_cmd(egui::ViewportCommand::Close); }
                }
            }
            if let Some(error) = &self.error {
                ui.add_space(14.);
                ui.colored_label(Color32::LIGHT_RED, format!("Error: {error}"));
                ui.label("Existing documents and chat data were not deleted.");
            }
            ui.add_space(20.);
            ui.separator();
            ui.label(RichText::new("ToneEdit Studio 1.2.1  |  FREE · No ads · No license activation  |  MIT License")
                .small().weak());
        });
        ctx.request_repaint_after(std::time::Duration::from_millis(250));
    }
}
