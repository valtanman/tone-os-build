fn main() {
    #[cfg(windows)]
    {
        let mut res = winres::WindowsResource::new();
        res.set_icon("../../assets/ToneEdit-Setup.ico");
        res.set("ProductName", "ToneEdit Studio");
        res.set("FileDescription", "ToneEdit Studio — Installation Wizard");
        res.compile().expect("Could not embed Windows setup icon");
    }
}
