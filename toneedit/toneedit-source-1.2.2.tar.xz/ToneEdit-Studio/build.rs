fn main() {
    #[cfg(windows)]
    {
        let mut res = winres::WindowsResource::new();
        res.set_icon("assets/ToneEdit.ico");
        res.set("ProductName", "ToneEdit Studio");
        res.set("FileDescription", "ToneEdit Studio — Native Rust editor and multi-AI chat");
        res.set("LegalCopyright", "ToneEdit Studio contributors");
        res.compile().expect("Could not embed Windows app icon");
    }
}
