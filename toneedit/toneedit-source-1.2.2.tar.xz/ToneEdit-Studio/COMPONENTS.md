# ToneEdit Studio — Rust component architecture (v1.2.1)

The editor is an MIT-licensed, Rust-only native app. Each visible workbench
feature lives in `src/components/<feature>.rs`. No user-specific profiles,
product affiliation or default persona is baked in.

## UI component contract

```rust
pub trait WorkbenchComponent {
    fn id(&self) -> &'static str;
    fn title(&self) -> &'static str;
    fn region(&self) -> &'static str;
    fn visible(&self, _app: &EditorApp) -> bool { true }
    fn render(&self, app: &mut EditorApp, ctx: &egui::Context, actions: &mut Vec<Action>);
}
```

`src/components/mod.rs` mounts the components in one registry with stable IDs.
The menu bar and toolbar are mounted first. Side panels and the task/status
panels reserve their space before the central editor is rendered. Dialogs
render after the editor. The `View → Components` window lets users show or
hide optional workbench components (explorer, search, Markdown preview, task
console, AI chat) without uninstalling their engine modules.

| Component ID | Source file | UI / purpose |
|---|---|---|
| `workbench.menu` | `shell.rs` | file/edit/view/tools/AI/help menu |
| `workbench.toolbar` | `shell.rs` | quick actions and document title |
| `edit.search` | `find.rs` | regex search and replacement |
| `workbench.status` | `status.rs` | cursor, encoding, line ending |
| `dev.console` | `status.rs` | background Cargo tasks, workspace search results |
| `workspace.explorer` | `explorer.rs` | recursive folder tree |
| `view.preview` | `preview.rs` | Markdown rendered view |
| `ai.chat` | `ai_chat.rs` | multi-provider AI chat and connection dialogs |
| `edit.document` | `editor.rs` | editor buffer, syntax colors, tabs |
| `workbench.dialogs` | `dialogs.rs` | confirmation and about windows |

`theme.rs` contains the shared blue-accent dark / light theme, applied by the
workbench when the user changes appearance. Theme state is stored in the local
session alongside component visibility preferences.

## Engine modules and boundaries

- `document.rs`: encoding, backups, atomic saves and recovery persistence.
- `search.rs`: regex and editor offsets; `workspace.rs`: folder-wide search.
- `syntax.rs`: syntax highlighting and language detection.
- `ai.rs`: vendor adapters, conversation model, credentials, and API requests.
- `ai/providers/`: `AiProviderAdapter` interface and separate OpenAI-compatible,
  Anthropic Messages, and Gemini generateContent adapter components.
- `google_oauth.rs`: OAuth 2.0 browser/PKCE, credential tokens.
- `main.rs`: session state, command routing and workbench lifecycle.
- `packaging/setup` and `packaging/uninstall`: separately built native Rust EXEs.
- `tools/build-all`: Rust-only build orchestrator and ZIP packager.

## Extend a component

1. Add a new `src/components/my_feature.rs` (or an engine module under `src/`).
2. Implement `WorkbenchComponent` in the feature module, using a stable unique `id`.
3. Add the module, static instance and ordered registry entry in `components/mod.rs`.
4. Route user actions through the `Action` enum; put state on `EditorApp` or in a
   self-contained feature model. Keep any credentials in the OS vault, not state JSON.
5. Add a unit test for its behavior and the registry test will check duplicate IDs.
6. Run `cargo test` and use the one-command Windows release builder.

For a new AI API family, implement `AiProviderAdapter` under `src/ai/providers/`
and register it in `adapter(vendor)`. OpenAI-compatible providers share one
adapter, so adding another compatible endpoint does not require a new class.

**Current scope:** This is compile-time component composition, not a runtime
untrusted native plugin loader, language server or an online marketplace. The
user-visible components are not individually distributable executable files;
they are linked together into the main Rust `toneedit-studio.exe` binary.
